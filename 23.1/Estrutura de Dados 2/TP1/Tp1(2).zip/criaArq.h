# ifndef criaArq_h
# define criaArq_h
#include <stdio.h>
#include "item.h"

char* generateRandomString(int);
void arquivo(int, int);

# endif