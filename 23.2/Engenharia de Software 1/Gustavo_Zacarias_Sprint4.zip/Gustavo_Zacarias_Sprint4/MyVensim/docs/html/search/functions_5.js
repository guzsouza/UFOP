var searchData=
[
  ['logisticalflow_84',['LogisticalFlow',['../class_logistical_flow.html#a0621ff1c066566d303fb8eb626958394',1,'LogisticalFlow']]],
  ['logisticalfunctionaltest_85',['logisticalFunctionalTest',['../_funcional_tests_8cpp.html#a873703af6cfeefd5cfd67aef5493ea68',1,'FuncionalTests.cpp']]]
];
