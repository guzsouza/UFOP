g++ -Wall src/models/*.cpp -c
g++ -Wall tests/funcional/*.cpp -c
g++ -Wall tests/unit/*.cpp -c

g++ *.o -lm -o bin/exe
rm *.o
bin/./exe