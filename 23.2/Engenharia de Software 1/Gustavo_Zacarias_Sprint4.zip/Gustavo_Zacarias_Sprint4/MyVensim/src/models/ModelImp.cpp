#include "ModelImp.h"

ModelImp::ModelImp() {}

ModelImp::ModelImp(int argument_id, std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows)
    : id(argument_id), title(argument_title),  systems(systems), flows(flows){};

ModelImp::ModelImp(int argument_id, std::string argument_title)
    : id(argument_id), title(argument_title),  systems({}), flows({}){};

std::string ModelImp::getTitle() const {
    return title;
}

int ModelImp::getId() const {
    return id;
}

void ModelImp::setTitle(std::string argumentTitle){
  title = argumentTitle;
}

void ModelImp::setId(int argumentId){
  id = argumentId;
}

ModelImp::ModelImp(const ModelImp &copyOther) {

    if (this == &copyOther) 
        return;

    id = copyOther.getId();

  // Copia os sistemas
    for (auto it = copyOther.systemsBegin(); it != copyOther.systemsEnd(); ++it) {
      this->add(*it);
    }

    // Limpa os fluxos atuais
    flows.clear();

    // Copia os fluxos
    for (auto it = copyOther.flowsBegin(); it != copyOther.flowsEnd(); ++it) {
        this->add(*it);
    }
}


ModelImp::iteratorSystem ModelImp::systemsBegin() const { 
    return systems.begin(); 
}

ModelImp::iteratorSystem ModelImp::systemsEnd() const { 
    return systems.end(); 
}

ModelImp::iteratorFlow ModelImp::flowsBegin() const { 
    return flows.begin(); 
}

ModelImp::iteratorFlow ModelImp::flowsEnd() const { 
    return flows.end(); 
}

ModelImp &ModelImp ::operator=(const ModelImp &newOther) {
  if(&newOther == this)
    return *this;
  id = newOther.getId();
  
  systems.clear();
  // Copia os sistemas
  for (auto it = newOther.systems.begin(); it != newOther.systems.end(); ++it) {
      this->add(*it);
  }

  // Limpa os fluxos atuais
  flows.clear();

  // Copia os fluxos
  for (auto it = newOther.flows.begin(); it != newOther.flows.end(); ++it) {
      this->add(*it);
  }
  
  return *this;
}

ModelImp::~ModelImp(){};

bool ModelImp::add(Flow *newFlow) {
  flows.push_back(newFlow);
  return true;
}

bool ModelImp::add(System *newSystem) {
  systems.push_back(newSystem);
  return true;
}

bool ModelImp::execute(int initial_time, int end_time, int step) {
  for (int i = initial_time; i < end_time; i += step) {
      double flows_results[flows.size()];

      for (auto it = flows.begin(); it != flows.end(); ++it) {
        double result = (*it)->execute();
        flows_results[it - flows.begin()] = result;
      }

      for (size_t j = 0; j < flows.size(); j++) {
        System *source = flows[j]->getSource();
        source->setAccumulator(source->getAccumulator() - flows_results[j]);

        System *target = flows[j]->getTarget();
        target->setAccumulator(target->getAccumulator() + flows_results[j]);
      }
    }

    return true;
}
