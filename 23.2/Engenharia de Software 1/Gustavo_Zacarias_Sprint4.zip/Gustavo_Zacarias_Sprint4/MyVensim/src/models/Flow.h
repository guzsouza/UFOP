#pragma once

#include <string>
#include <vector>
#include <typeinfo>
#include "System.h"

/**
 * @brief Represents an abstract base class for flows in a simulation model.
 */
class Flow {

public:
    /**
     * @brief Virtual destructor for Flow.
     */
    virtual ~Flow(){};

    /**
     * @brief Sets the target system for the flow.
     * @param newTarget The new target system.
     */
    virtual void setTarget(System *) = 0;

    /**
     * @brief Sets the source system for the flow.
     * @param newSource The new source system.
     */
    virtual void setSource(System *) = 0;

    /**
     * @brief Gets the title of the flow.
     * @return The title of the flow.
     */
    virtual std::string getTitle() const = 0;

    /**
     * @brief Gets the unique identifier of the flow.
     * @return The unique identifier of the flow.
     */
    virtual int getId() const = 0;

    /**
     * @brief Gets the source system of the flow.
     * @return The source system of the flow.
     */
    virtual System *getSource() const = 0;

    /**
     * @brief Gets the target system of the flow.
     * @return The target system of the flow.
     */
    virtual System *getTarget() const = 0;

    /**
     * @brief Clears the source system of the flow.
     * @return True if the source system was cleared successfully, false otherwise.
     */
    virtual bool clearSource() = 0;

    /**
     * @brief Clears the target system of the flow.
     * @return True if the target system was cleared successfully, false otherwise.
     */
    virtual bool clearTarget() = 0;

    /**
     * @brief Executes the flow.
     * @return The result of the flow execution.
     */
    virtual double execute() const = 0;
};
