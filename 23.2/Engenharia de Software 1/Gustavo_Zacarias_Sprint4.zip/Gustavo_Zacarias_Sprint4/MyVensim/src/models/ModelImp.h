#pragma once

#include "Model.h"

/**
 * @brief Represents a concrete implementation of the Model interface in the system.
 */
class ModelImp : public Model {
private:
    int id; ///< Unique identifier for the ModelImp.
    std::string title; ///< Title of the ModelImp.
    std::vector<System*> systems; ///< Vector of systems in the ModelImp.
    std::vector<Flow*> flows; ///< Vector of flows in the ModelImp.

public:
    /**
     * @brief Default constructor for ModelImp.
     */
    ModelImp();

    /**
     * @brief Parameterized constructor for ModelImp.
     * @param argument_id The unique identifier for the ModelImp.
     * @param argument_title The title of the ModelImp.
     * @param systems Vector of systems in the ModelImp.
     * @param flows Vector of flows in the ModelImp.
     */
    ModelImp(int argument_id, std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows);

    /**
     * @brief Gets the title of the ModelImp.
     * @return The title of the ModelImp.
     */
    std::string getTitle() const;

    /**
     * @brief Gets the unique identifier of the ModelImp.
     * @return The unique identifier of the ModelImp.
     */
    int getId() const;

    /**
     * @brief Sets the title of the ModelImp.
     * @param argumentTitle The new title of the ModelImp.
     */
    void setTitle(std::string argumentTitle);

    /**
     * @brief Sets the unique identifier of the ModelImp.
     * @param argumentId The new unique identifier of the ModelImp.
     */
    void setId(int argumentId);

    /**
     * @brief Constructor for ModelImp with only id and title.
     * @param argument_id The unique identifier for the ModelImp.
     * @param argument_title The title of the ModelImp.
     */
    ModelImp(int argument_id, std::string argument_title);

    /**
     * @brief Iterator type for iterating over systems in the ModelImp.
     */
    typedef std::vector<System*>::const_iterator iteratorSystem;

    /**
     * @brief Gets the iterator pointing to the beginning of the systems in the ModelImp.
     * @return Iterator pointing to the beginning of the systems.
     */
    iteratorSystem systemsBegin() const;

    /**
     * @brief Gets the iterator pointing to the end of the systems in the ModelImp.
     * @return Iterator pointing to the end of the systems.
     */
    iteratorSystem systemsEnd() const;

    /**
     * @brief Iterator type for iterating over flows in the ModelImp.
     */
    typedef std::vector<Flow*>::const_iterator iteratorFlow;

    /**
     * @brief Gets the iterator pointing to the beginning of the flows in the ModelImp.
     * @return Iterator pointing to the beginning of the flows.
     */
    iteratorFlow flowsBegin() const;

    /**
     * @brief Gets the iterator pointing to the end of the flows in the ModelImp.
     * @return Iterator pointing to the end of the flows.
     */
    iteratorFlow flowsEnd() const;

    /**
     * @brief Adds a new flow to the ModelImp.
     * @param newFlow The new flow to add.
     * @return True if the flow was added successfully, false otherwise.
     */
    bool add(Flow *newFlow);

    /**
     * @brief Adds a new system to the ModelImp.
     * @param newSystem The new system to add.
     * @return True if the system was added successfully, false otherwise.
     */
    bool add(System *newSystem);

    /**
     * @brief Executes the ModelImp for a specified time range and step.
     * @param initialTime The initial time for the simulation.
     * @param endTime The end time for the simulation.
     * @param step The time step for the simulation.
     * @return True if the execution was successful, false otherwise.
     */
    bool execute(int initialTime, int endTime, int step);

    /**
     * @brief Virtual destructor for ModelImp.
     */
    virtual ~ModelImp();

private:
    /**
     * @brief Assignment operator for ModelImp (private to prevent assignment).
     * @param newOther The ModelImp to assign.
     * @return Reference to the assigned ModelImp.
     */
    ModelImp &operator=(const ModelImp &newOther);

    /**
     * @brief Copy constructor for ModelImp (private to prevent copying).
     * @param copyOther The ModelImp to copy.
     */
    ModelImp(const ModelImp &copyOther);
};
