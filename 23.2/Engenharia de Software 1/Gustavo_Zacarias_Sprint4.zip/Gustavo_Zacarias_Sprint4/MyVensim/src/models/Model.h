#pragma once

#include <string>
#include <vector>
#include <typeinfo>
#include "Flow.h"

/**
 * @brief Represents an abstract base class for a simulation model.
 */
class Model {
public:
    /**
     * @brief Virtual destructor for the Model class.
     */
    virtual ~Model(){};

    /**
     * @brief Gets the title of the model.
     * @return The title of the model.
     */
    virtual std::string getTitle() const = 0;

    /**
     * @brief Gets the unique identifier of the model.
     * @return The unique identifier of the model.
     */
    virtual int getId() const = 0;

    /**
     * @brief Sets the title of the model.
     * @param argumentTitle The new title of the model.
     */
    virtual void setTitle(std::string argumentTitle) = 0;

    /**
     * @brief Sets the unique identifier of the model.
     * @param argumentId The new unique identifier of the model.
     */
    virtual void setId(int argumentId) = 0;

    /**
     * @brief Iterator type for iterating over systems in the model.
     */
    typedef std::vector<System*>::const_iterator iteratorSystem;

    /**
     * @brief Gets the iterator pointing to the beginning of the systems in the model.
     * @return Iterator pointing to the beginning of the systems.
     */
    virtual iteratorSystem systemsBegin() const = 0;

    /**
     * @brief Gets the iterator pointing to the end of the systems in the model.
     * @return Iterator pointing to the end of the systems.
     */
    virtual iteratorSystem systemsEnd() const = 0;

    /**
     * @brief Iterator type for iterating over flows in the model.
     */
    typedef std::vector<Flow*>::const_iterator iteratorFlow;

    /**
     * @brief Gets the iterator pointing to the beginning of the flows in the model.
     * @return Iterator pointing to the beginning of the flows.
     */
    virtual iteratorFlow flowsBegin() const = 0;

    /**
     * @brief Gets the iterator pointing to the end of the flows in the model.
     * @return Iterator pointing to the end of the flows.
     */
    virtual iteratorFlow flowsEnd() const = 0;

    /**
     * @brief Adds a new flow to the model.
     * @param newFlow The new flow to add.
     * @return True if the flow was added successfully, false otherwise.
     */
    virtual bool add(Flow *newFlow) = 0;

    /**
     * @brief Adds a new system to the model.
     * @param newSystem The new system to add.
     * @return True if the system was added successfully, false otherwise.
     */
    virtual bool add(System *newSystem) = 0;

    /**
     * @brief Executes the model for a specified time range and step.
     * @param initialTime The initial time for the simulation.
     * @param endTime The end time for the simulation.
     * @param step The time step for the simulation.
     * @return True if the execution was successful, false otherwise.
     */
    virtual bool execute(int initialTime, int endTime, int step) = 0;
};
