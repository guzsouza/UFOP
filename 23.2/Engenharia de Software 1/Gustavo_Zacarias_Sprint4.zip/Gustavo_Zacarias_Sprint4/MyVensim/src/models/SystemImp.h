#pragma once

#include "System.h"

/**
 * @brief Represents a concrete implementation of the System interface in the simulation model.
 */
class SystemImp : public System {
private:
    int id; ///< Unique identifier for the SystemImp.
    std::string title; ///< Title of the SystemImp.
    double accumulator; ///< Accumulator value of the SystemImp.

public:
    /**
     * @brief Default constructor for SystemImp.
     */
    SystemImp();

    /**
     * @brief Parameterized constructor for SystemImp.
     * @param argument_id The unique identifier for the SystemImp.
     * @param argument_title The title of the SystemImp.
     * @param argument_accumulator The initial accumulator value of the SystemImp.
     */
    SystemImp(int argument_id, std::string argument_title, double argument_accumulator);

    /**
     * @brief Copy constructor for System to SystemImp.
     * @param copyOther The System to copy.
     */
    SystemImp(const System &copyOther);

    /**
     * @brief Virtual destructor for SystemImp.
     */
    virtual ~SystemImp();

    /**
     * @brief Gets the current accumulator value of the SystemImp.
     * @return The accumulator value of the SystemImp.
     */
    const double getAccumulator();

    /**
     * @brief Gets the title of the SystemImp.
     * @return The title of the SystemImp.
     */
    std::string getTitle() const;

    /**
     * @brief Gets the unique identifier of the SystemImp.
     * @return The unique identifier of the SystemImp.
     */
    int getId() const;

    /**
     * @brief Gets the accumulator value of the SystemImp.
     * @return The accumulator value of the SystemImp.
     */
    int getAccumulator() const;

    /**
     * @brief Sets the accumulator value of the SystemImp.
     * @param argument_accumulator The new accumulator value.
     */
    void setAccumulator(double argument_accumulator);

private:
    /**
     * @brief Copy constructor for SystemImp (private to prevent copying).
     * @param copyOther The SystemImp to copy.
     */
    SystemImp(const SystemImp &copyOther);

    /**
     * @brief Assignment operator for SystemImp (private to prevent assignment).
     * @param newOther The SystemImp to assign.
     * @return Reference to the assigned SystemImp.
     */
    SystemImp &operator=(const SystemImp &newOther);
};
