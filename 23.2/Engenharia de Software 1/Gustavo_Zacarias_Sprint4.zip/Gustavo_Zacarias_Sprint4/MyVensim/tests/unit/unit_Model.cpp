#include "unit_Model.h"
#include "../../src/models/ModelImp.h"
#include "../../src/models/SystemImp.h"
#include "UnitTestFlow.h"

#include <cassert>
#include <complex>
#include <cstdio>

void unit_model_constructor() {
  Model *model = new ModelImp();
  assert(model->getId() == 0);
  assert(model->getTitle() == "");
  assert(model->systemsBegin() == model->systemsEnd());
  assert(model->flowsBegin() == model->flowsEnd());

  delete model;
}

void unit_model_constructor_with_id_and_title() {
  Model *model = new ModelImp(1, "Model 1");
  assert(model->getId() == 1);
  assert(model->getTitle() == "Model 1");
  assert(model->systemsBegin() == model->systemsEnd());
  assert(model->flowsBegin() == model->flowsEnd());

  delete model;
}

void unit_model_getId() {
  Model *model = new ModelImp(1, "Model 1");
  assert(model->getId() == 1);

  delete model;
}

void unit_model_getTitle() {
  Model *model = new ModelImp(1, "Model 1");
  assert(model->getTitle() == "Model 1");

  delete model;
}

void unit_model_add_system() {
  Model *model = new ModelImp(1, "Model 1");
  System *system = new SystemImp(1, "System 1", 1.0);

  assert(model->add(system));
  assert(model->systemsBegin() != model->systemsEnd());
  assert(model->flowsBegin() == model->flowsEnd());

  delete model;
  delete system;
}

void unit_model_add_flow() {
  Model *model = new ModelImp(1, "Model 1");
  System *source = new SystemImp(1, "Source", 1.0);
  System *target = new SystemImp(2, "Target", 1.0);
  Flow *flow = new UnitTestFlow(1, "Flow 1", source, target);

  assert(model->add(flow));
  assert(model->systemsBegin() == model->systemsEnd());
  assert(model->flowsBegin() != model->flowsEnd());

  delete model;
  delete source;
  delete target;
  delete flow;
}

void unit_model_systemsBegin() {
  Model *model = new ModelImp(1, "Model 1");
  System *system = new SystemImp(1, "System 1", 1.0);

  assert(model->add(system));
  assert(model->systemsBegin() != model->systemsEnd());
  assert((*model->systemsBegin())->getId() == 1);
  assert((*model->systemsBegin())->getTitle() == "System 1");
  assert((*model->systemsBegin())->getAccumulator() == 1.0);

  delete model;
  delete system;
}

void unit_model_systemsEnd() {
  Model *model = new ModelImp(1, "Model 1");
  System *system = new SystemImp(1, "System 1", 1.0);

  assert(model->add(system));
  assert(model->systemsBegin() != model->systemsEnd());
  assert(++model->systemsBegin() == model->systemsEnd());

  delete model;
  delete system;
}

void unit_model_flowsBegin() {
  Model *model = new ModelImp(1, "Model 1");
  System *source = new SystemImp(1, "Source", 1.0);
  System *target = new SystemImp(2, "Target", 1.0);
  Flow *flow = new UnitTestFlow(1, "Flow 1", source, target);

  assert(model->add(flow));
  assert(model->flowsBegin() != model->flowsEnd());
  assert((*model->flowsBegin())->getId() == 1);
  assert((*model->flowsBegin())->getTitle() == "Flow 1");
  assert((*model->flowsBegin())->getSource() == source);
  assert((*model->flowsBegin())->getTarget() == target);

  delete model;
  delete source;
  delete target;
  delete flow;
}

void unit_model_flowsEnd() {
  Model *model = new ModelImp(1, "Model 1");
  System *source = new SystemImp(1, "Source", 1.0);
  System *target = new SystemImp(2, "Target", 1.0);
  Flow *flow = new UnitTestFlow(1, "Flow 1", source, target);

  assert(model->add(flow));
  assert(model->flowsBegin() != model->flowsEnd());
  assert(++model->flowsBegin() == model->flowsEnd());

  delete model;
  delete source;
  delete target;
  delete flow;
}

void unit_model_execute() {
  Model *model = new ModelImp(1, "Model 1");
  System *source = new SystemImp(1, "Source", 300.0);
  System *target = new SystemImp(2, "Target", 100.0);
  Flow *flow = new UnitTestFlow(1, "Flow 1", source, target);

  assert(model->add(source));
  assert(model->add(target));
  assert(model->add(flow));

  model->execute(0, 100, 1);

  const double expected_source_value = 109.8097;
  const double expected_targetAccumulator = 290.1903;

  assert(fabs(round((source->getAccumulator() * 10000)) -
              10000 * expected_source_value) < 0.0001);
  assert(fabs(round((target->getAccumulator() * 10000)) -
              10000 * expected_targetAccumulator) < 0.0001);

  delete model;
  delete source;
  delete target;
  delete flow;
}

void run_model_unit_tests() {
  unit_model_constructor();
  unit_model_constructor_with_id_and_title();
  unit_model_getId();
  unit_model_getTitle();
  unit_model_add_system();
  unit_model_add_flow();
  unit_model_systemsBegin();
  unit_model_systemsEnd();
  unit_model_flowsBegin();
  unit_model_flowsEnd();
  unit_model_execute();
}