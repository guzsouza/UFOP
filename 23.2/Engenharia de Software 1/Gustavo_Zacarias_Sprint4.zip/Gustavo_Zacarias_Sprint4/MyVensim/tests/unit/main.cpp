#include "unit_Flow.h"
#include "unit_Model.h"
#include "unit_System.h"
#include <cstdlib>

int main() {
  run_system_unit_tests();
  run_flow_unit_tests();
  run_model_unit_tests();

  return EXIT_SUCCESS;
}