#include "../../src/models/FlowImp.h"

class UnitTestFlow : public FlowImp {

public:
  UnitTestFlow();
  UnitTestFlow(int id, std::string title);
  UnitTestFlow(int id, std::string title, System *source, System *target);
  UnitTestFlow(Flow &flow);
  virtual double execute() const;
};
