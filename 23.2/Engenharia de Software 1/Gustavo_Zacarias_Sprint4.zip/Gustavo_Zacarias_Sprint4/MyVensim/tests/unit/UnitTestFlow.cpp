#include "UnitTestFlow.h"

UnitTestFlow::UnitTestFlow() : FlowImp() {}

UnitTestFlow::UnitTestFlow(int id, std::string title) : FlowImp(id, title) {}

UnitTestFlow::UnitTestFlow(int id, std::string title, System *source, System *target)
    : FlowImp(id, title, source, target) {}

UnitTestFlow::UnitTestFlow(Flow &flow) : FlowImp(flow) {}

double UnitTestFlow::execute() const { return getSource()->getAccumulator() * 0.01; }