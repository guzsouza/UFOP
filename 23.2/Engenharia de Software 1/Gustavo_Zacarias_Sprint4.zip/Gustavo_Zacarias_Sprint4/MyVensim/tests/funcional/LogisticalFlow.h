#include "../../src/models/FlowImp.h"


/**
 * @brief Represents a logistical flow in the simulation model.
 */
class LogisticalFlow : public FlowImp {
public:
  /**
   * @brief Constructor for LogisticalFlow.
   * @param id The unique identifier for the flow.
   * @param title The title of the flow.
   */
  LogisticalFlow(int id, std::string title);

  /**
   * @brief Executes the logistical flow.
   * @return The result of the flow execution.
   */
  virtual double execute() const;

  /**
   * @brief Destructor for LogisticalFlow.
   */
  virtual ~LogisticalFlow();
};

