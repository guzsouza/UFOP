#include "ExponentialFlow.h"

ExponentialFlow :: ExponentialFlow(int id, std::string title) : FlowImp(id, title) {};

double ExponentialFlow :: execute() const { 
    return getSource()->getAccumulator() * 0.01; 
}

ExponentialFlow :: ~ExponentialFlow(){};

