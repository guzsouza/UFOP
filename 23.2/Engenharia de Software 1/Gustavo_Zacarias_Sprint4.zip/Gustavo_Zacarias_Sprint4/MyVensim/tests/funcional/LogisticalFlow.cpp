#include "LogisticalFlow.h"

LogisticalFlow :: LogisticalFlow(int id, std::string title) : FlowImp(id, title) {};

double LogisticalFlow :: execute() const {
    double value = getTarget()->getAccumulator();
    return 0.01 * value * (1 - value / 70);
}

LogisticalFlow :: ~LogisticalFlow(){};