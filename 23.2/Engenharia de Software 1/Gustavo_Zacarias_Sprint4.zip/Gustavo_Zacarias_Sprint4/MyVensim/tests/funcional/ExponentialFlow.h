#include "../../src/models/FlowImp.h"

// Classes for acceptance tests

/**
 * @brief Represents an exponential flow in the simulation model.
 */
class ExponentialFlow : public FlowImp {
public:
  /**
   * @brief Constructor for ExponentialFlow.
   * @param id The unique identifier for the flow.
   * @param title The title of the flow.
   */
  ExponentialFlow(int id, std::string title);

  /**
   * @brief Executes the exponential flow.
   * @return The result of the flow execution.
   */
  virtual double execute() const;

  /**
   * @brief Destructor for ExponentialFlow.
   */
  virtual ~ExponentialFlow();
};