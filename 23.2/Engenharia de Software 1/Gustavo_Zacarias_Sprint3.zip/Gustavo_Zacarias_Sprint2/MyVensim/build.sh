g++ -Wall src/models/Model.cpp -c
g++ -Wall src/models/Flow.cpp -c
g++ -Wall src/models/System.cpp -c
g++ -Wall tests/funcional/main.cpp -c
g++ main.o Model.o Flow.o System.o -lm -o bin/exe
rm *.o
bin/./exe