#include "Flow.h"

Flow :: Flow(){};
Flow :: Flow(int argument_id, std::string argument_title, System *argument_source, System *argument_target):
    id(argument_id),
    title(argument_title),
    source(argument_source),
    target(argument_target)
{};
Flow :: Flow(const Flow &copyOther){
    if(this == &copyOther)
      return;
    id = copyOther.getId();
    title = copyOther.getTitle();
    source = copyOther.getSource();
    target = copyOther.getTarget();
}

std::string Flow::getTitle() const{
  return title;
}

int Flow::getId() const{
    return id;
}

Flow::Flow(int argument_id, std::string argument_title)
      : id(argument_id), title(argument_title){}

Flow :: ~Flow(){};
Flow & Flow :: operator=(const Flow &newOther){
    if(&newOther == this)
        return *this;
    id = newOther.getId();
    title = newOther.getTitle();
    source = newOther.getSource();
    target = newOther.getTarget();
    return *this;
}
void Flow :: setTarget(System *newTarget){
    target = newTarget;
};
void Flow :: setSource(System *newSource){
    source = newSource;
};
void Flow :: clearSource(){
    source = nullptr;
};
void Flow :: clearTarget(){
    target = nullptr;
};

System *Flow :: getTarget() const{
    return target;
}

System *Flow :: getSource() const{
    return source;
}