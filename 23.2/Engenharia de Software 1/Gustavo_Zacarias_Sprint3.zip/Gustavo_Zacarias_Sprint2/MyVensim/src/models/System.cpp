#include "System.h"

System :: System(){};
System :: System(int argument_id, std::string argument_title, double argument_accumulator):
    id(argument_id), 
    title(argument_title),
    accumulator(argument_accumulator)
{};
System :: ~System(){};
const double System :: getAccumulator(){
    return accumulator;
};
void System :: setAccumulator(double argument_accumulator){
    accumulator = argument_accumulator;
};

std::string System::getTitle() const{
  return title;
}

int System::getId() const{
    return id;
}

int System::getAccumulator()const{
    return accumulator;
}

System :: System(const System &copyOther){
    if(&copyOther == this)
        return;
    id = copyOther.getId();
    title = copyOther.getTitle();
    accumulator = copyOther.getAccumulator();
};
System& System :: operator=(const System &newOther){
    if (this != &newOther){
        accumulator = newOther.accumulator;
    }
    return *this;
};