#include "Model.h"

Model::Model() {}

Model::Model(int argument_id, std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows)
    : id(argument_id), title(argument_title),  systems(systems), flows(flows){};

Model::Model(int argument_id, std::string argument_title)
    : id(argument_id), title(argument_title),  systems({}), flows({}){};

std::string Model::getTitle() const {
    return title;
}

int Model::getId() const {
    return id;
}

void Model::setTitle(std::string argumentTitle){
  title = argumentTitle;
}

void Model::setId(int argumentId){
  id = argumentId;
}

Model::Model(const Model &copyOther) {

    if (this == &copyOther) 
        return;

    id = copyOther.getId();

  // Copia os sistemas
    for (auto it = copyOther.systemsBegin(); it != copyOther.systemsEnd(); ++it) {
      this->add(*it);
    }

    // Limpa os fluxos atuais
    flows.clear();

    // Copia os fluxos
    for (auto it = copyOther.flowsBegin(); it != copyOther.flowsEnd(); ++it) {
        this->add(*it);
    }
}


Model::iteratorSystem Model::systemsBegin() const { 
    return systems.begin(); 
}

Model::iteratorSystem Model::systemsEnd() const { 
    return systems.end(); 
}

Model::iteratorFlow Model::flowsBegin() const { 
    return flows.begin(); 
}

Model::iteratorFlow Model::flowsEnd() const { 
    return flows.end(); 
}

Model &Model ::operator=(const Model &newOther) {
  if(&newOther == this)
    return *this;
  id = newOther.getId();
  
  systems.clear();
  // Copia os sistemas
  for (auto it = newOther.systems.begin(); it != newOther.systems.end(); ++it) {
      this->add(*it);
  }

  // Limpa os fluxos atuais
  flows.clear();

  // Copia os fluxos
  for (auto it = newOther.flows.begin(); it != newOther.flows.end(); ++it) {
      this->add(*it);
  }
  
  return *this;
}

Model::~Model(){};

bool Model::add(Flow *newFlow) {
  flows.push_back(newFlow);
  return true;
}

bool Model::add(System *newSystem) {
  systems.push_back(newSystem);
  return true;
}

bool Model::execute(int initial_time, int end_time, int step) {
  for (int i = initial_time; i < end_time; i += step) {
      double flows_results[flows.size()];

      for (auto it = flows.begin(); it != flows.end(); ++it) {
        double result = (*it)->execute();
        flows_results[it - flows.begin()] = result;
      }

      for (size_t j = 0; j < flows.size(); j++) {
        System *source = flows[j]->getSource();
        source->setAccumulator(source->getAccumulator() - flows_results[j]);

        System *target = flows[j]->getTarget();
        target->setAccumulator(target->getAccumulator() + flows_results[j]);
      }
    }

    return true;
}
