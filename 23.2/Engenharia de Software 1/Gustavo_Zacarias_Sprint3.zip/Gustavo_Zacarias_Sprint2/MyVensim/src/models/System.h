#include <string>
#include <vector>
#include <typeinfo>

/**
 * @brief Represents a system in the simulation model.
 */
class System {
private:
    int id; ///< Unique identifier for the system.
    std::string title; ///< Title of the system.
    double accumulator; ///< Accumulator value of the system.

public:
    /**
     * @brief Default constructor for System.
     */
    System();

    /**
     * @brief Parameterized constructor for System.
     * @param argument_id The unique identifier for the system.
     * @param argument_title The title of the system.
     * @param argument_accumulator The initial accumulator value of the system.
     */
    System(int argument_id, std::string argument_title, double argument_accumulator);

    /**
     * @brief Virtual destructor for System.
     */
    virtual ~System();

    /**
     * @brief Gets the current accumulator value of the system.
     * @return The accumulator value of the system.
     */
    const double getAccumulator();

    /**
     * @brief Gets the title of the system.
     * @return The title of the system.
     */
    std::string getTitle() const;

    /**
     * @brief Gets the unique identifier of the system.
     * @return The unique identifier of the system.
     */
    int getId() const;

    /**
     * @brief Gets the accumulator value of the system.
     * @return The accumulator value of the system.
     */
    int getAccumulator() const;

    /**
     * @brief Sets the accumulator value of the system.
     * @param argument_accumulator The new accumulator value.
     */
    void setAccumulator(double argument_accumulator);

private:
    /**
     * @brief Copy constructor for System (private to prevent copying).
     * @param copyOther The system to copy.
     */
    System(const System &copyOther);

    /**
     * @brief Assignment operator for System (private to prevent assignment).
     * @param newOther The system to assign.
     * @return Reference to the assigned system.
     */
    System &operator=(const System &newOther);
};
