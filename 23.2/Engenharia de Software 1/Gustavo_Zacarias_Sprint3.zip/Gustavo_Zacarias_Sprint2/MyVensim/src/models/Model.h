#include <string>
#include <vector>
#include <typeinfo>
#include "Flow.h"

/**
 * @brief Represents a simulation model.
 */
class Model {
private:
    int id; ///< Unique identifier for the model.
    std::string title; ///< Title of the model.
    std::vector<System*> systems; ///< Vector of systems in the model.
    std::vector<Flow*> flows; ///< Vector of flows in the model.

public:
    /**
     * @brief Default constructor for Model.
     */
    Model();

    /**
     * @brief Parameterized constructor for Model.
     * @param argument_id The unique identifier for the model.
     * @param argument_title The title of the model.
     * @param systems Vector of systems in the model.
     * @param flows Vector of flows in the model.
     */
    Model(int argument_id, std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows);

    /**
     * @brief Gets the title of the model.
     * @return The title of the model.
     */
    std::string getTitle() const;

    /**
     * @brief Gets the unique identifier of the model.
     * @return The unique identifier of the model.
     */
    int getId() const;

    /**
     * @brief Sets the title of the model.
     * @param argumentTitle The new title of the model.
     */
    void setTitle(std::string argumentTitle);

    /**
     * @brief Sets the unique identifier of the model.
     * @param argumentId The new unique identifier of the model.
     */
    void setId(int argumentId);

    /**
     * @brief Constructor for Model with only id and title.
     * @param argument_id The unique identifier for the model.
     * @param argument_title The title of the model.
     */
    Model(int argument_id, std::string argument_title);

    /**
     * @brief Iterator type for iterating over systems in the model.
     */
    typedef std::vector<System*>::const_iterator iteratorSystem;

    /**
     * @brief Gets the iterator pointing to the beginning of the systems in the model.
     * @return Iterator pointing to the beginning of the systems.
     */
    iteratorSystem systemsBegin() const;

    /**
     * @brief Gets the iterator pointing to the end of the systems in the model.
     * @return Iterator pointing to the end of the systems.
     */
    iteratorSystem systemsEnd() const;

    /**
     * @brief Iterator type for iterating over flows in the model.
     */
    typedef std::vector<Flow*>::const_iterator iteratorFlow;

    /**
     * @brief Gets the iterator pointing to the beginning of the flows in the model.
     * @return Iterator pointing to the beginning of the flows.
     */
    iteratorFlow flowsBegin() const;

    /**
     * @brief Gets the iterator pointing to the end of the flows in the model.
     * @return Iterator pointing to the end of the flows.
     */
    iteratorFlow flowsEnd() const;

    /**
     * @brief Adds a new flow to the model.
     * @param newFlow The new flow to add.
     * @return True if the flow was added successfully, false otherwise.
     */
    bool add(Flow *newFlow);

    /**
     * @brief Adds a new system to the model.
     * @param newSystem The new system to add.
     * @return True if the system was added successfully, false otherwise.
     */
    bool add(System *newSystem);

    /**
     * @brief Executes the model for a specified time range and step.
     * @param initialTime The initial time for the simulation.
     * @param endTime The end time for the simulation.
     * @param step The time step for the simulation.
     * @return True if the execution was successful, false otherwise.
     */
    bool execute(int initialTime, int endTime, int step);

    /**
     * @brief Virtual destructor for Model.
     */
    virtual ~Model();

private:
    /**
     * @brief Assignment operator for Model (private to prevent assignment).
     * @param newOther The model to assign.
     * @return Reference to the assigned model.
     */
    Model &operator=(const Model &newOther);

    /**
     * @brief Copy constructor for Model (private to prevent copying).
     * @param copyOther The model to copy.
     */
    Model(const Model &copyOther);
};
