#include <string>
#include <vector>
#include <typeinfo>
#include "System.h"

/**
 * @brief Represents a flow in the system.
 */
class Flow {
private:
    int id; ///< Unique identifier for the flow.
    std::string title; ///< Title of the flow.
    System *source; ///< Source system of the flow.
    System *target; ///< Target system of the flow.

public:
    /**
     * @brief Default constructor for Flow.
     */
    Flow();

    /**
     * @brief Parameterized constructor for Flow.
     * @param argument_id The unique identifier for the flow.
     * @param argument_title The title of the flow.
     * @param argument_source The source system of the flow.
     * @param argument_target The target system of the flow.
     */
    Flow(int argument_id, std::string argument_title, System *argument_source, System *argument_target);

    /**
     * @brief Constructor for Flow with only id and title.
     * @param argument_id The unique identifier for the flow.
     * @param argument_title The title of the flow.
     */
    Flow(int argument_id, std::string argument_title);

    /**
     * @brief Virtual destructor for Flow.
     */
    virtual ~Flow();

    /**
     * @brief Sets the target system for the flow.
     * @param newTarget The new target system.
     */
    void setTarget(System *newTarget);

    /**
     * @brief Sets the source system for the flow.
     * @param newSource The new source system.
     */
    void setSource(System *newSource);

    /**
     * @brief Gets the title of the flow.
     * @return The title of the flow.
     */
    std::string getTitle() const;

    /**
     * @brief Gets the unique identifier of the flow.
     * @return The unique identifier of the flow.
     */
    int getId() const;

    /**
     * @brief Gets the source system of the flow.
     * @return The source system of the flow.
     */
    System *getSource() const;

    /**
     * @brief Gets the target system of the flow.
     * @return The target system of the flow.
     */
    System *getTarget() const;

    /**
     * @brief Clears the source system of the flow.
     */
    void clearSource();

    /**
     * @brief Clears the target system of the flow.
     */
    void clearTarget();

    /**
     * @brief Executes the flow.
     * @return The result of the flow execution.
     */
    virtual double execute() const = 0;

private:
    /**
     * @brief Copy constructor for Flow (private to prevent copying).
     * @param copyOther The flow to copy.
     */
    Flow(const Flow &copyOther);

    /**
     * @brief Assignment operator for Flow (private to prevent assignment).
     * @param newOther The flow to assign.
     * @return Reference to the assigned flow.
     */
    Flow &operator=(const Flow &newOther);
};
