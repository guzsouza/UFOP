var searchData=
[
  ['add_221',['add',['../class_model.html#a94c8319fa87ab9f33a4ac2b362837e5d',1,'Model::add(System *sys)=0'],['../class_model.html#ab7df81041f62f049cfc6e4d50dcaf721',1,'Model::add(Flow *flow)=0'],['../class_model_body.html#abf9443cba27067cf76b083939eab0b44',1,'ModelBody::add(System *sys)'],['../class_model_body.html#aa970c15679b82c7d265f04f5bbf737e4',1,'ModelBody::add(Flow *flow)'],['../class_model_handle.html#aab5d917f2decd6d5c8a0b8cd6907cfc1',1,'ModelHandle::add(System *sys)'],['../class_model_handle.html#a1c2fe71daa814c09442b735a81f9ba53',1,'ModelHandle::add(Flow *flow)']]],
  ['attach_222',['attach',['../class_body.html#a5d53322c76a6952d096cb7564ac86db1',1,'Body']]]
];
