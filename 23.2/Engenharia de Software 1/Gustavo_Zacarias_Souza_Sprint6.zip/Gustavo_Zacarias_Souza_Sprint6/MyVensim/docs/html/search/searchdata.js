var indexSectionsWithContent =
{
  0: "abcdefghilmnoprstuv~",
  1: "bcefhlmsu",
  2: "fhmsu",
  3: "abcdefghilmorsu~",
  4: "fmnprstv",
  5: "fms",
  6: "u",
  7: "dgmr"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Macros"
};

