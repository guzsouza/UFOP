var searchData=
[
  ['flowbody_246',['FlowBody',['../class_flow_body.html#a34952906cfe6d8c0fa91555d7e479341',1,'FlowBody::FlowBody(const Flow &amp;flow)'],['../class_flow_body.html#a7912384af496741bee4a2179a19069f2',1,'FlowBody::FlowBody(string name=&quot;&quot;, System *source=NULL, System *target=NULL)']]],
  ['flowhandle_247',['FlowHandle',['../class_flow_handle.html#ad179f6721751865be5fa1983f098a183',1,'FlowHandle::FlowHandle(const FlowHandle &amp;flow)'],['../class_flow_handle.html#a05ebf219b406089ae6e2a3a550f0c4d0',1,'FlowHandle::FlowHandle(string name=&quot;&quot;, System *source=NULL, System *target=NULL)']]]
];
