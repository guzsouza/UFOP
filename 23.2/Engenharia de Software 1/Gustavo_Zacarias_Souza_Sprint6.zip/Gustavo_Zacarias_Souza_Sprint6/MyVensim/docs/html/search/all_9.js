var searchData=
[
  ['logisticalfuncionaltest_50',['logisticalFuncionalTest',['../funcional__tests_8cpp.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_tests.cpp'],['../funcional__tests_8h.html#a60914db64bde71b56d69320797266c29',1,'logisticalFuncionalTest():&#160;funcional_tests.cpp']]],
  ['logisticflow_51',['LogisticFlow',['../class_logistic_flow.html',1,'LogisticFlow'],['../class_logistic_flow.html#a97bdad6917cc83240a1a3d976c7a8d4d',1,'LogisticFlow::LogisticFlow()']]]
];
