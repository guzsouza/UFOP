#include <ios>
#include <iostream>
#include <fstream>
#include <string>

void memory_usage(double& vm_usage, double& resident_set);