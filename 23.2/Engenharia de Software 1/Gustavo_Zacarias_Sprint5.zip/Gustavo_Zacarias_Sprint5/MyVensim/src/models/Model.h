#pragma once

#include <string>
#include <vector>
#include <typeinfo>
#include "Flow.h"
#include <type_traits>


/**
 * @brief Represents an abstract base class for a simulation model.
 */
class Model {
protected:
    /**
    * @brief Adds a model to the application.
    * @param model Pointer to the Model object to be added.
    * @return True if the model was added successfully, false otherwise.
    */
    static bool add(Model *model);

    /**
        * @brief Adds a new flow to the model.
        * @param newFlow The new flow to add.
        * @return True if the flow was added successfully, false otherwise.
        */
    virtual bool add(Flow *newFlow) = 0;

public:
    /**
     * @brief Virtual destructor for the Model class.
     */
    virtual ~Model(){};

    /**
     * @brief Gets the title of the model.
     * @return The title of the model.
     */
    virtual std::string getTitle() const = 0;

    /**
     * @brief Sets the title of the model.
     * @param argumentTitle The new title of the model.
     */
    virtual void setTitle(std::string argumentTitle) = 0;

    /**
   * @brief Create a model object
   *
   * @param title The title of the model.
   * @return Model& A Model that belongs to this model.
   */
  static Model &createModel(std::string title);

  /**
   * @brief Create a system object
   *
   * @param title The title of the system.
   * @param value The initial value of the system.
   * @return System& A System that belongs to this model.
   */
  virtual System &createSystem(std::string title, double value) = 0;

  /**
   * @brief Removes a system from the model.
   * @param system Pointer to the System object to be removed.
   * @return The confirmation of the removal.
   */
  virtual bool removeSystem(System *system) = 0;

  /**
   * @brief Create a flow object
   *
   * @param title The title of the flow
   * @return A Flow that belongs to this model.
   */
  template <typename T> Flow &createFlow(std::string title) {
    static_assert(std::is_base_of<Flow, T>::value, "T must inherit from Flow");

    T *flow = new T(title);
    add(flow);
    return *flow;
  }

  /**
   * @brief Create a flow object
   *
   * @param title The title of the flow
   * @param source The source system of the flow.
   * @param target The target system of the flow.
   * @return Flow & A Flow that belongs to this model.
   */
    template <typename T>
    Flow &createFlow(std::string title, System *source, System *target) {
        static_assert(std::is_base_of<Flow, T>::value, "T must inherit from Flow");

        T *flow = new T(title, source, target);
        add(flow);
        return *flow;
    };

    /**
   * @brief Removes a flow from the model.
   * @param flow Pointer to the Flow object to be removed.
   * @return The confirmation of the removal.
   */
    virtual bool removeFlow(Flow *flow) = 0;

    /**
     * @brief Iterator type for iterating over systems in the model.
     */
    typedef std::vector<System*>::const_iterator iteratorSystem;

    /**
     * @brief Gets the iterator pointing to the beginning of the systems in the model.
     * @return Iterator pointing to the beginning of the systems.
     */
    virtual iteratorSystem systemsBegin() const = 0;

    /**
     * @brief Gets the iterator pointing to the end of the systems in the model.
     * @return Iterator pointing to the end of the systems.
     */
    virtual iteratorSystem systemsEnd() const = 0;

    /**
     * @brief Iterator type for iterating over flows in the model.
     */
    typedef std::vector<Flow*>::const_iterator iteratorFlow;

    /**
     * @brief Gets the iterator pointing to the beginning of the flows in the model.
     * @return Iterator pointing to the beginning of the flows.
     */
    virtual iteratorFlow flowsBegin() const = 0;

    /**
     * @brief Gets the iterator pointing to the end of the flows in the model.
     * @return Iterator pointing to the end of the flows.
     */
    virtual iteratorFlow flowsEnd() const = 0;

    /**
     * @brief Executes the model for a specified time range and step.
     * @param initialTime The initial time for the simulation.
     * @param endTime The end time for the simulation.
     * @param step The time step for the simulation.
     * @return True if the execution was successful, false otherwise.
     */
    virtual int execute(int initialTime, int endTime, int step) const = 0;
};
