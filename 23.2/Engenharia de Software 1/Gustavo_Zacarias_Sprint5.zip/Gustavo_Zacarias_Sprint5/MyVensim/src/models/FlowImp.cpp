#include "FlowImp.h"

FlowImp :: FlowImp(){};

FlowImp :: FlowImp(std::string argument_title, System *argument_source, System *argument_target):
    title(argument_title),
    source(argument_source),
    target(argument_target)
{};

FlowImp :: FlowImp(const FlowImp &copyOther){
    if(this == &copyOther)
      return;
    title = copyOther.getTitle();
    source = copyOther.getSource();
    target = copyOther.getTarget();
}

FlowImp ::FlowImp(const Flow &copyOther) {
  if (this != &copyOther) {
    title = copyOther.getTitle();
    source = copyOther.getSource();
    target = copyOther.getTarget();
  }
}

std::string FlowImp::getTitle() const{
  return title;
}

FlowImp::FlowImp(std::string argument_title)
      : title(argument_title){}

FlowImp :: ~FlowImp(){};
FlowImp & FlowImp :: operator=(const FlowImp &newOther){
    if(&newOther == this)
        return *this;
    title = newOther.getTitle();
    source = newOther.getSource();
    target = newOther.getTarget();
    return *this;
}
void FlowImp :: setTarget(System *newTarget){
    target = newTarget;
};
void FlowImp :: setSource(System *newSource){
    source = newSource;
};
bool FlowImp :: clearSource(){
    if(source == nullptr)
        return false;
    
    source = nullptr;
    return true;
};
bool FlowImp :: clearTarget(){
    if (target == nullptr)
        return false;
    
    
    target = nullptr;
    return true;
};

System *FlowImp :: getTarget() const{
    return target;
}

System *FlowImp :: getSource() const{
    return source;
}