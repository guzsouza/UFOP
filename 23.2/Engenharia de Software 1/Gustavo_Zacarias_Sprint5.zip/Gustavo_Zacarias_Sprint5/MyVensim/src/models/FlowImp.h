#pragma once

#include "Flow.h"

/**
 * @brief Represents a concrete implementation of the Flow interface in the system.
 */
class FlowImp : public Flow {
private:
    std::string title; ///< Title of the FlowImp.
    System *source; ///< Source system of the FlowImp.
    System *target; ///< Target system of the FlowImp.

public:
    /**
     * @brief Default constructor for FlowImp.
     */
    FlowImp();

    /**
     * @brief Parameterized constructor for FlowImp.
     * @param argument_title The title of the FlowImp.
     * @param argument_source The source system of the FlowImp.
     * @param argument_target The target system of the FlowImp.
     */
    FlowImp(std::string argument_title, System *argument_source, System *argument_target);

    /**
     * @brief Constructor for FlowImp with only id and title.
     * @param argument_title The title of the FlowImp.
     */
    FlowImp(std::string argument_title);

    /**
     * @brief Constructor for FlowImp with a Flow object.
     */
    FlowImp(const Flow &copyOther);

    /**
     * @brief Virtual destructor for FlowImp.
     */
    virtual ~FlowImp();

    /**
     * @brief Sets the target system for the FlowImp.
     * @param newTarget The new target system.
     */
    void setTarget(System *newTarget);

    /**
     * @brief Sets the source system for the FlowImp.
     * @param newSource The new source system.
     */
    void setSource(System *newSource);

    /**
     * @brief Gets the title of the FlowImp.
     * @return The title of the FlowImp.
     */
    std::string getTitle() const;

    /**
     * @brief Gets the source system of the FlowImp.
     * @return The source system of the FlowImp.
     */
    System *getSource() const;

    /**
     * @brief Gets the target system of the FlowImp.
     * @return The target system of the FlowImp.
     */
    System *getTarget() const;

    /**
     * @brief Clears the source system of the FlowImp.
     * @return True if the source system was cleared successfully, false otherwise.
     */
    bool clearSource();

    /**
     * @brief Clears the target system of the FlowImp.
     * @return True if the target system was cleared successfully, false otherwise.
     */
    bool clearTarget();

    /**
     * @brief Executes the FlowImp.
     * @return The result of the FlowImp execution.
     */
    virtual double execute() const = 0;

    /**
     * @brief Copy constructor for FlowImp (private to prevent copying).
     * @param copyOther The FlowImp to copy.
     */
    FlowImp(const FlowImp &copyOther);

    /**
     * @brief Assignment operator for FlowImp (private to prevent assignment).
     * @param newOther The FlowImp to assign.
     * @return Reference to the assigned FlowImp.
     */
    FlowImp &operator=(const FlowImp &newOther);
};
