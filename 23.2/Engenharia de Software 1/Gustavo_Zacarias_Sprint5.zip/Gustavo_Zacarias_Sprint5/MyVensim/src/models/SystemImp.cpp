#include "SystemImp.h"

SystemImp :: SystemImp(){};
SystemImp :: SystemImp(std::string argument_title, double argument_accumulator):
    title(argument_title),
    accumulator(argument_accumulator)
{};
SystemImp :: ~SystemImp(){};
const double SystemImp :: getAccumulator(){
    return accumulator;
};
void SystemImp :: setAccumulator(double argument_accumulator){
    accumulator = argument_accumulator;
};

std::string SystemImp::getTitle() const{
  return title;
}

int SystemImp::getAccumulator()const{
    return accumulator;
}

SystemImp :: SystemImp(const SystemImp &copyOther){
    if(&copyOther == this)
        return;
    title = copyOther.getTitle();
    accumulator = copyOther.getAccumulator();
};

SystemImp :: SystemImp(const System &copyOther){
    if(&copyOther == this)
        return;
    title = copyOther.getTitle();
    accumulator = copyOther.getAccumulator();
};

SystemImp& SystemImp :: operator=(const SystemImp &newOther){
    if (this != &newOther){
        accumulator = newOther.accumulator;
    }
    return *this;
};