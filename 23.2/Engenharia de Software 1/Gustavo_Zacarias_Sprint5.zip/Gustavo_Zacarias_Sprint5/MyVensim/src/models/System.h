#pragma once

#include <string>
#include <vector>
#include <typeinfo>

/**
 * @brief Represents an abstract base class for a system in the simulation model.
 */
class System {
public:
    /**
     * @brief Virtual destructor for the System class.
     */
    virtual ~System(){};

    /**
     * @brief Gets the current accumulator value of the system.
     * @return The accumulator value of the system.
     */
    virtual const double getAccumulator() = 0;

    /**
     * @brief Gets the title of the system.
     * @return The title of the system.
     */
    virtual std::string getTitle() const = 0;

    /**
     * @brief Gets the accumulator value of the system.
     * @return The accumulator value of the system.
     */
    virtual int getAccumulator() const = 0;

    /**
     * @brief Sets the accumulator value of the system.
     * @param argument_accumulator The new accumulator value.
     */
    virtual void setAccumulator(double argument_accumulator) = 0;
};
