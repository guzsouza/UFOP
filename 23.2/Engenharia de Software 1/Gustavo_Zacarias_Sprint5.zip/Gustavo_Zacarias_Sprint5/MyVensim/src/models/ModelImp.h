#pragma once

#include "Model.h"
#include "Flow.h"

/**
 * @brief Represents a concrete implementation of the Model interface in the system.
 */
class ModelImp : public Model {
private:
    std::string title; ///< Title of the ModelImp.
    std::vector<System*> systems; ///< Vector of systems in the ModelImp.
    std::vector<Flow*> flows; ///< Vector of flows in the ModelImp.
    static std::vector<Model *> models; ///< The models of the application.

    /**
     * @brief Default constructor for ModelImp.
     */
    ModelImp();

    /**
     * @brief Parameterized constructor for ModelImp.
     * @param argument_id The unique identifier for the ModelImp.
     * @param argument_title The title of the ModelImp.
     * @param systems Vector of systems in the ModelImp.
     * @param flows Vector of flows in the ModelImp.
     */
    ModelImp(std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows);

    /**
     * @brief Constructor for ModelImp with only id and title.
     * @param argument_id The unique identifier for the ModelImp.
     * @param argument_title The title of the ModelImp.
     */
    ModelImp(std::string argument_title);

    /**
     * @brief Virtual destructor for ModelImp.
     */
    virtual ~ModelImp();

    /**
     * @brief Assignment operator for ModelImp (private to prevent assignment).
     * @param newOther The ModelImp to assign.
     * @return Reference to the assigned ModelImp.
     */
    ModelImp &operator=(const ModelImp &newOther);

    /**
     * @brief Copy constructor for ModelImp (private to prevent copying).
     * @param copyOther The ModelImp to copy.
     */
    ModelImp(const ModelImp &copyOther);

        /**
    * @brief Adds a model to the application.
    * @param model Pointer to the Model object to be added.
    * @return True if the model was added successfully, false otherwise.
    */
    static bool add(Model *model);

    /**
    * @brief Adds a system to the model.
    * @param system Pointer to the System object to be added.
    * @return True if the system was added successfully, false otherwise.
    */
    virtual bool add(System *system);

protected:

    /**
     * @brief Adds a new flow to the ModelImp.
     * @param newFlow The new flow to add.
     * @return True if the flow was added successfully, false otherwise.
     */
    bool add(Flow *newFlow);

public:

    /**
    * @brief Removes a flow from the model
    * @param flow Pointer to the Flow object to be removed.
    * @return The confirmation of the removal.
    */
    virtual bool removeFlow(Flow *flow);

    /**
    * @brief Removes a system from the model.
    * @param system Pointer to the System object to be removed.
    * @return The confirmation of the removal.
    */
    virtual bool removeSystem(System *system);

    /**
    * @brief Create a system object
    *
    * @param title The title of the system.
    * @param value The initial value of the system.
    * @return System& A System that belongs to this model.
    */
    virtual System &createSystem(std::string title, double value);

    /**
    * @brief Create a model object and add it to the list of models.
    *
    * @param title The title of the model.
    * @return Model& A Model object.
    */
    static Model &createModel(std::string title);

    /**
     * @brief Iterator type for iterating over systems in the ModelImp.
     */
    typedef std::vector<System*>::const_iterator iteratorSystem;

    /**
     * @brief Gets the iterator pointing to the beginning of the systems in the ModelImp.
     * @return Iterator pointing to the beginning of the systems.
     */
    iteratorSystem systemsBegin() const;

    /**
     * @brief Gets the iterator pointing to the end of the systems in the ModelImp.
     * @return Iterator pointing to the end of the systems.
     */
    iteratorSystem systemsEnd() const;

    /**
     * @brief Iterator type for iterating over flows in the ModelImp.
     */
    typedef std::vector<Flow*>::const_iterator iteratorFlow;

    /**
     * @brief Gets the iterator pointing to the beginning of the flows in the ModelImp.
     * @return Iterator pointing to the beginning of the flows.
     */
    iteratorFlow flowsBegin() const;

    /**
     * @brief Gets the iterator pointing to the end of the flows in the ModelImp.
     * @return Iterator pointing to the end of the flows.
     */
    iteratorFlow flowsEnd() const;

    /**
     * @brief Executes the ModelImp for a specified time range and step.
     * @param initialTime The initial time for the simulation.
     * @param endTime The end time for the simulation.
     * @param step The time step for the simulation.
     * @return True if the execution was successful, false otherwise.
     */
    int execute(int initialTime, int endTime, int step) const;

    /**
     * @brief Gets the title of the ModelImp.
     * @return The title of the ModelImp.
     */
    std::string getTitle() const;

    /**
     * @brief Sets the title of the ModelImp.
     * @param argumentTitle The new title of the ModelImp.
     */
    void setTitle(std::string argumentTitle);
};
