#include "ModelImp.h"
#include "Flow.h"
#include "System.h"
#include "SystemImp.h"

std::vector<Model *> ModelImp::models;

ModelImp::ModelImp() {}

ModelImp::ModelImp(std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows)
    :title(argument_title),  systems(systems), flows(flows){};

ModelImp::ModelImp(std::string argument_title)
    : title(argument_title),  systems({}), flows({}){};

std::string ModelImp::getTitle() const {
    return title;
}

void ModelImp::setTitle(std::string argumentTitle){
  title = argumentTitle;
}

ModelImp::ModelImp(const ModelImp &copyOther) {

    if (this == &copyOther) 
        return;

  title = copyOther.title;

  // Copia os sistemas
    for (auto it = copyOther.systemsBegin(); it != copyOther.systemsEnd(); ++it) {
      this->add(*it);
    }

    // Limpa os fluxos atuais
    flows.clear();

    // Copia os fluxos
    for (auto it = copyOther.flowsBegin(); it != copyOther.flowsEnd(); ++it) {
        this->add(*it);
    }
}

Model &ModelImp::createModel(std::string title) {
  Model *model = new ModelImp(title);
  add(model);
  return *model;
}

System &ModelImp::createSystem(std::string title, double value) {
  System *system = new SystemImp(title, value);
  add(system);
  return *system;
}

Model &Model::createModel(std::string title) {
  return ModelImp::createModel(title);
}

bool ModelImp::removeSystem(System *system) {
  for (auto it = systems.begin(); it != systems.end(); ++it) {
    if (*it == system) {
      systems.erase(it);
      return true;
    }
  }

  return false;
}

bool ModelImp::removeFlow(Flow *flow) {
  for (auto it = flows.begin(); it != flows.end(); ++it) {
    if (*it == flow) {
      flows.erase(it);
      return true;
    }
  }

  return false;
}

ModelImp::iteratorSystem ModelImp::systemsBegin() const { 
    return systems.begin(); 
}

ModelImp::iteratorSystem ModelImp::systemsEnd() const { 
    return systems.end(); 
}

ModelImp::iteratorFlow ModelImp::flowsBegin() const { 
    return flows.begin(); 
}

ModelImp::iteratorFlow ModelImp::flowsEnd() const { 
    return flows.end(); 
}

ModelImp &ModelImp ::operator=(const ModelImp &newOther) {
  if(&newOther == this)
    return *this;

  title = newOther.title;

  systems.clear();
  // Copia os sistemas
  for (auto it = newOther.systems.begin(); it != newOther.systems.end(); ++it) {
      this->add(*it);
  }

  // Limpa os fluxos atuais
  flows.clear();
  // Copia os fluxos
  for (auto it = newOther.flows.begin(); it != newOther.flows.end(); ++it) {
      this->add(*it);
  }
  
  return *this;
}

ModelImp::~ModelImp(){
  for (auto it = systems.begin(); it != systems.end(); ++it) {
    delete *it;
  }
  
  for (auto it = flows.begin(); it != flows.end(); ++it) {
    delete *it;
  }

  for (auto it = models.begin(); it != models.end(); ++it) {
    if ((*it) == this) {
      models.erase(it);
    }
  }
  models.clear();
};

bool ModelImp::add(Flow *newFlow) {
  flows.push_back(newFlow);
  return true;
}

bool ModelImp::add(System *newSystem) {
  systems.push_back(newSystem);
  return true;
}

bool ModelImp::add(Model *model) {
  models.push_back(model);

  return true;
}

int ModelImp::execute(int initialTime, int endTime, int step) const {
  int steps_count = 0;

  for (int i = initialTime; i < endTime; i += step) {
    double flows_results[flows.size()];

    for (auto it = flows.begin(); it != flows.end(); ++it) {
      double result = (*it)->execute();
      flows_results[it - flows.begin()] = result;
    }

    for (size_t j = 0; j < flows.size(); j++) {
      System *source = flows[j]->getSource();
      source->setAccumulator(source->getAccumulator() - flows_results[j]);

      System *target = flows[j]->getTarget();
      target->setAccumulator(target->getAccumulator() + flows_results[j]);
    }

    steps_count++;
  }

  return steps_count;
}
