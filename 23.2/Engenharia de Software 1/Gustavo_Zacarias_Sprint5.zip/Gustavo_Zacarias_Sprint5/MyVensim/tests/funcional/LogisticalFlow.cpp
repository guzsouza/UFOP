#include "LogisticalFlow.h"

LogisticalFlow :: LogisticalFlow(std::string title) : FlowImp(title) {};

double LogisticalFlow :: execute() const {
    double value = getTarget()->getAccumulator();
    return 0.01 * value * (1 - value / 70);
}

LogisticalFlow :: ~LogisticalFlow(){};