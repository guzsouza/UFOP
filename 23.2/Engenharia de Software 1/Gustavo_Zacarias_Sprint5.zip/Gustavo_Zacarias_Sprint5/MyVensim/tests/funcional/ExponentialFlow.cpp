#include "ExponentialFlow.h"

ExponentialFlow :: ExponentialFlow(std::string title) : FlowImp(title) {};

ExponentialFlow::ExponentialFlow(std::string title, System *source,
                                 System *target)
    : FlowImp(title, source, target) {}

double ExponentialFlow :: execute() const { 
    return getSource()->getAccumulator() * 0.01; 
}

ExponentialFlow :: ~ExponentialFlow(){};

