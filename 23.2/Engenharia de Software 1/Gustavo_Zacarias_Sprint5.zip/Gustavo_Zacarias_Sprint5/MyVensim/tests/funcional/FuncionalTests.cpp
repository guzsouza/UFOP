#include "../../src/models/Model.h"
#include "../../src/models/System.h"
#include "ExponentialFlow.h"
#include "LogisticalFlow.h"
#include <cassert>
#include <cmath>

void exponential_functional_test() {
  Model &model = Model::createModel("model_1");
  System &s1 = model.createSystem("pop1", 100.0);
  System &s2 = model.createSystem("pop2", 0.0);
  Flow &f1 = model.createFlow<ExponentialFlow>("Exponencial", &s1, &s2);

  model.execute(0, 100, 1);

  assert(fabs((round((s1.getAccumulator() * 10000)) - 10000 * 36.6032)) < 0.0001);
  assert(fabs((round((s2.getAccumulator() * 10000)) - 10000 * 63.3968)) < 0.0001);

  delete &model;
}

void logistical_functional_test() {
  Model &model = Model::createModel("model_1");
  System &s1 = model.createSystem("pop1", 100.0);
  System &s2 = model.createSystem("pop2", 10.0);
  Flow &f1 = model.createFlow<LogisticalFlow>("Logístico");

  f1.setSource(&s1);
  f1.setTarget(&s2);

  model.execute(0, 100, 1);

  assert(fabs((round((s1.getAccumulator() * 10000)) - 10000 * 88.2167)) < 0.0001);
  assert(fabs((round((s2.getAccumulator() * 10000)) - 10000 * 21.7833)) < 0.0001);

  delete &model;
}

void complex_functional_test() {
  Model &model = Model::createModel("acceptance_3");
  System &q1 = model.createSystem("q1", 100.0);
  System &q2 = model.createSystem("q2", 0.0);
  System &q3 = model.createSystem("q3", 100.0);
  System &q4 = model.createSystem("q4", 0.0);
  System &q5 = model.createSystem("q5", 0.0);

  Flow &f = model.createFlow<ExponentialFlow>("f", &q1, &q2);
  Flow &t = model.createFlow<ExponentialFlow>("t", &q2, &q3);
  Flow &u = model.createFlow<ExponentialFlow>("u", &q3, &q4);
  Flow &v = model.createFlow<ExponentialFlow>("v", &q4, &q1);
  Flow &g = model.createFlow<ExponentialFlow>("g", &q1, &q3);
  Flow &r = model.createFlow<ExponentialFlow>("r", &q2, &q5);

  model.execute(0, 100, 1);

  assert(fabs((round((q1.getAccumulator() * 10000)) - 10000 * 31.8513)) < 0.0001);
  assert(fabs((round((q2.getAccumulator() * 10000)) - 10000 * 18.4003)) < 0.0001);
  assert(fabs((round((q3.getAccumulator() * 10000)) - 10000 * 77.1143)) < 0.0001);
  assert(fabs((round((q4.getAccumulator() * 10000)) - 10000 * 56.1728)) < 0.0001);
  assert(fabs((round((q5.getAccumulator() * 10000)) - 10000 * 16.4612)) < 0.0001);

  delete &model;
}

int main() {
  exponential_functional_test();
  logistical_functional_test();
  complex_functional_test();

  return EXIT_SUCCESS;
}