#include "../../src/models/FlowImp.h"

// Classes for acceptance tests

/**
 * @brief Represents an exponential flow in the simulation model.
 */
class ExponentialFlow : public FlowImp {
public:

  /**
   * @brief Constructor for ExponentialFlow.
   * @param title The title of the exponential flow.
   * @param source The source system of the exponential flow.
   * @param target The target system of the exponential flow.
   */
  ExponentialFlow(std::string title, System *source, System *target);


  /**
   * @brief Constructor for ExponentialFlow.
   * @param title The title of the flow.
   */
  ExponentialFlow(std::string title);

  /**
   * @brief Executes the exponential flow.
   * @return The result of the flow execution.
   */
  virtual double execute() const;

  /**
   * @brief Destructor for ExponentialFlow.
   */
  virtual ~ExponentialFlow();
};