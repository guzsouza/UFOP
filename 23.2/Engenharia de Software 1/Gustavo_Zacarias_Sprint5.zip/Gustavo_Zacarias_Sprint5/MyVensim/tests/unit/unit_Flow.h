#pragma once

/**
 * @file
 * @brief Contains unit tests for the Flow class.
 */

/**
 * @brief Test case for constructing a flow.
 *
 * This test verifies the construction of a flow object.
 */
void unit_flow_constructor();

/**
 * @brief Test case for constructing a flow with title.
 *
 * This test verifies the construction of a flow object with specified ID
 * and title.
 */
void unit_flow_constructor_with_title();

/**
 * @brief Test case for constructing a flow with all fields.
 *
 * This test verifies the construction of a flow object with all specified
 * fields.
 */
void unit_flow_constructor_with_all_fields();

/**
 * @brief Test case for copying a flow.
 *
 * This test verifies the copy constructor of the flow class.
 */
void unit_flow_constructor_copy();


/**
 * @brief Test case for retrieving the title of a flow.
 *
 * This test verifies the functionality of the getTitle() method.
 */
void unit_flow_getTitle();

/**
 * @brief Test case for retrieving the source of a flow.
 *
 * This test verifies the functionality of the getSource() method.
 */
void unit_flow_getSource();

/**
 * @brief Test case for setting the source of a flow.
 *
 * This test verifies the functionality of the setSource() method.
 */
void unit_flow_setSource();

/**
 * @brief Test case for clearing the source of a flow.
 *
 * This test verifies the functionality of the clearSource() method.
 */
void unit_flow_clearSource();

/**
 * @brief Test case for retrieving the target of a flow.
 *
 * This test verifies the functionality of the getTarget() method.
 */
void unit_flow_getTarget();

/**
 * @brief Test case for setting the target of a flow.
 *
 * This test verifies the functionality of the setTarget() method.
 */
void unit_flow_setTarget();

/**
 * @brief Test case for clearing the target of a flow.
 *
 * This test verifies the functionality of the clearTarget() method.
 */
void unit_flow_clearTarget();

/**
 * @brief Test case for executing a flow.
 *
 * This test verifies the functionality of the execute() method.
 */
void unit_flow_execute();

/**
 * @brief Run all tests related to the UnitFlow class.
 *
 * This function executes all the tests for the UnitFlow class.
 */
void run_flow_unit_tests();
