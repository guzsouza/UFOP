#include "unit_Flow.h"
#include "../../src/models/SystemImp.h"
#include "UnitTestFlow.h"
#include <cassert>
#include <cmath>

void unit_flow_constructor() {
  Flow *flow = new UnitTestFlow();
  assert(flow->getTitle() == "");

  delete flow;
}

void unit_flow_constructor_with_id_and_title() {
  Flow *flow = new UnitTestFlow("Flow 1");
  assert(flow->getTitle() == "Flow 1");

  delete flow;
}

void unit_flow_constructor_with_all_fields() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getTitle() == "Flow 1");
  assert(flow->getSource() == source);
  assert(flow->getTarget() == target);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_constructor_copy() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);
  Flow *flow_copy = new UnitTestFlow(*flow);

  assert(flow_copy->getTitle() == "Flow 1");
  assert(flow_copy->getSource() == source);
  assert(flow_copy->getTarget() == target);

  delete source;
  delete target;
  delete flow;
  delete flow_copy;
}

void unit_flow_getTitle() {
  Flow *flow = new UnitTestFlow("Flow 1");
  assert(flow->getTitle() == "Flow 1");
  delete flow;
}

void unit_flow_getSource() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getSource() == source);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_setSource() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getSource() == source);

  System *new_source = new SystemImp("New Source", 1.0);
  flow->setSource(new_source);

  assert(flow->getSource() == new_source);
  assert(flow->getTarget() == target);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_clearSource() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getSource() == source);

  flow->clearSource();

  assert(flow->getSource() == nullptr);
  assert(flow->getTarget() == target);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_getTarget() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getTarget() == target);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_setTarget() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getTarget() == target);

  System *new_target = new SystemImp("New Target", 1.0);
  flow->setTarget(new_target);

  assert(flow->getTarget() == new_target);
  assert(flow->getSource() == source);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_clearTarget() {
  System *source = new SystemImp("Source", 1.0);
  System *target = new SystemImp("Target", 1.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  assert(flow->getTarget() == target);

  flow->clearTarget();

  assert(flow->getTarget() == nullptr);
  assert(flow->getSource() == source);

  delete source;
  delete target;
  delete flow;
}

void unit_flow_execute() {
  System *source = new SystemImp("Source", 10.1);
  System *target = new SystemImp("Target", 200.0);

  Flow *flow = new UnitTestFlow("Flow 1", source, target);

  double expected_result = 0.101;

  assert(fabs((round((flow->execute() * 10000)) - 10000 * expected_result)) <
         0.0001);

  delete source;
  delete target;
  delete flow;
}

void run_flow_unit_tests() {
  unit_flow_constructor();
  unit_flow_constructor_with_id_and_title();
  unit_flow_constructor_with_all_fields();
  unit_flow_constructor_copy();
  unit_flow_getTitle();
  unit_flow_getSource();
  unit_flow_setSource();
  unit_flow_clearSource();
  unit_flow_getTarget();
  unit_flow_setTarget();
  unit_flow_clearTarget();
  unit_flow_execute();
}