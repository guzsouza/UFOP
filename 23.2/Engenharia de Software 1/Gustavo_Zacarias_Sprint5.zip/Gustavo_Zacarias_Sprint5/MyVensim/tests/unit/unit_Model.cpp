#include "unit_Model.h"
#include "../../src/models/Model.h"
#include "UnitTestFlow.h"
#include <cassert>

void unit_model_constructor() {
  Model &model = Model::createModel("Model 1");
  assert(model.getTitle() == "Model 1");
  assert(model.systemsBegin() == model.systemsEnd());
  assert(model.flowsBegin() == model.flowsEnd());

  delete &model;
}

void unit_model_getTitle() {
  Model &model = Model::createModel("Model 1");
  assert(model.getTitle() == "Model 1");

  delete &model;
}

void unit_model_add_system() {
  Model &model = Model::createModel("Model 1");
  System &system = model.createSystem("System 1", 1.0);

  assert(model.systemsBegin() != model.systemsEnd());

  delete &model;
}

void unit_model_removeSystem() {
  Model &model = Model::createModel("Model 1");
  System &system = model.createSystem("System 1", 1.0);

  assert(model.systemsBegin() != model.systemsEnd());
  model.removeSystem(&system);
  assert(model.systemsBegin() == model.systemsEnd());

  delete &model;
}

void unit_model_add_flow() {
  Model &model = Model::createModel("Model 1");
  System &source = model.createSystem("Source", 1.0);
  System &target = model.createSystem("Target", 1.0);
  Flow &flow = model.createFlow<UnitTestFlow>("Flow 1", &source, &target);

  assert(model.flowsBegin() != model.flowsEnd());

  delete &model;
}

void unit_model_remove_flow() {
  Model &model = Model::createModel("Model 1");
  System &source = model.createSystem("Source", 1.0);
  System &target = model.createSystem("Target", 1.0);
  Flow &flow = model.createFlow<UnitTestFlow>("Flow 1", &source, &target);

  assert(model.flowsBegin() != model.flowsEnd());
  model.removeFlow(&flow);
  assert(model.flowsBegin() == model.flowsEnd());

  delete &model;
}

void unit_model_systemsBegin() {
  Model &model = Model::createModel("Model 1");
  System &system = model.createSystem("System 1", 1.0);

  assert(model.systemsBegin() != model.systemsEnd());
  assert((*model.systemsBegin())->getTitle() == "System 1");
  assert((*model.systemsBegin())->getAccumulator() == 1.0);

  delete &model;
}

void unit_model_systemsEnd() {
  Model &model = Model::createModel("Model 1");
  System &system = model.createSystem("System 1", 1.0);

  assert(model.systemsBegin() != model.systemsEnd());
  assert(++model.systemsBegin() == model.systemsEnd());

  delete &model;
}

void unit_model_flowsBegin() {
  Model &model = Model::createModel("Model 1");
  Flow &flow = model.createFlow<UnitTestFlow>("Flow 1");

  assert(model.flowsBegin() != model.flowsEnd());
  assert((*model.flowsBegin())->getTitle() == "Flow 1");

  delete &model;
}

void unit_model_flowsEnd() {
  Model &model = Model::createModel("Model 1");
  Flow &flow = model.createFlow<UnitTestFlow>("Flow 1");

  assert(model.flowsBegin() != model.flowsEnd());
  assert(++model.flowsBegin() == model.flowsEnd());

  delete &model;
}

void unit_model_execute() {
  Model &model = Model::createModel("Model 1");

  int initial_time = 10;
  int end_time = 100;
  int steps = model.execute(initial_time, end_time, 1);

  assert(steps == (end_time - initial_time));

  delete &model;
}

void run_model_unit_tests() {
  unit_model_constructor();
  unit_model_getTitle();
  unit_model_add_system();
  unit_model_removeSystem();
  unit_model_add_flow();
  unit_model_remove_flow();
  unit_model_systemsBegin();
  unit_model_systemsEnd();
  unit_model_flowsBegin();
  unit_model_flowsEnd();
  unit_model_execute();
}