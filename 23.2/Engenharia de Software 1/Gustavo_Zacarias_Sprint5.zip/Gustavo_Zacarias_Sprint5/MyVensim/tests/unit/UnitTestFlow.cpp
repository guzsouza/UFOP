#include "UnitTestFlow.h"

UnitTestFlow::UnitTestFlow() : FlowImp() {}

UnitTestFlow::UnitTestFlow(std::string title) : FlowImp(title) {}

UnitTestFlow::UnitTestFlow(std::string title, System *source, System *target)
    : FlowImp(title, source, target) {}

UnitTestFlow::UnitTestFlow(Flow &flow) : FlowImp(flow) {}

double UnitTestFlow::execute() const { return getSource()->getAccumulator() * 0.01; }