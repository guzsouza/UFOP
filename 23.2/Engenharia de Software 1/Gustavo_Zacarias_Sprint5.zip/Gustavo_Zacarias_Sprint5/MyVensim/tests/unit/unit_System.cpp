#include "unit_System.h"
#include "../../src/models/SystemImp.h"

#include <cassert>
#include <cmath>

void unit_system_constructor() {
  System *system = new SystemImp();
  assert(system->getTitle() == "");
  assert(fabs((round((system->getAccumulator() * 10000)) - 10000 * 0.0)) < 0.0001);

  delete system;
}

void unit_system_constructor_with_fields() {
  System *system = new SystemImp("System 1", 1.0);
  assert(system->getTitle() == "System 1");
  assert(fabs((round((system->getAccumulator() * 10000)) - 10000 * 1.0)) < 0.0001);

  delete system;
}

void unit_system_constructor_copy() {
  System *system = new SystemImp("System 1", 1.0);
  System *system_copy = new SystemImp(*system);
  assert(system_copy->getTitle() == "System 1");
  assert(fabs((round((system->getAccumulator() * 10000)) - 10000 * 1.0)) < 0.0001);

  delete system;
  delete system_copy;
}

void unit_system_getTitle() {
  System *system = new SystemImp("System 1", 1.0);
  assert(system->getTitle() == "System 1");
  delete system;
}

void unit_system_getAccumulator() {
  System *system = new SystemImp("System 1", 1.0);
  assert(fabs((round((system->getAccumulator() * 10000)) - 10000 * 1.0)) < 0.0001);
  delete system;
}

void unit_system_setAccumulator() {
  System *system = new SystemImp("System 1", 1.0);
  assert(fabs((round((system->getAccumulator() * 10000)) - 10000 * 1.0)) < 0.0001);

  system->setAccumulator(2.0);
  assert(fabs((round((system->getAccumulator() * 10000)) - 10000 * 2.0)) < 0.0001);
  delete system;
}

void run_system_unit_tests() {
  unit_system_constructor();
  unit_system_constructor_with_fields();
  unit_system_constructor_copy();
  unit_system_getTitle();
  unit_system_getAccumulator();
  unit_system_setAccumulator();
}