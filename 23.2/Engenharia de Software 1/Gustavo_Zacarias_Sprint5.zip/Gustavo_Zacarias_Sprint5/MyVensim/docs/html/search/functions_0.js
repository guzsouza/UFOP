var searchData=
[
  ['add_140',['add',['../class_model.html#a56868a99f1a8ccd0db54514a4c570993',1,'Model::add(Model *model)'],['../class_model.html#a07798721b702ef4e4bb9bd4bade84422',1,'Model::add(Flow *newFlow)=0'],['../class_model_imp.html#aebaf141130439cab64f96b5c12b2b47a',1,'ModelImp::add(Model *model)'],['../class_model_imp.html#acc6c08b06200353df45918ea5f1fd24d',1,'ModelImp::add(System *system)'],['../class_model_imp.html#ac07e551063719374bc4b343d26db54cb',1,'ModelImp::add(Flow *newFlow)']]]
];
