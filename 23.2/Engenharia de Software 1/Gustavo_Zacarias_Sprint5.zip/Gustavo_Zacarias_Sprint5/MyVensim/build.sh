g++ src/models/*.cpp -c
g++ tests/funcional/*.cpp -c
g++ tests/unit/*.cpp -c

g++ *.o -lm -o bin/exe
rm *.o
bin/./exe