#include <iostream>
#include <set>
#include <unordered_set>
#include <vector>

using namespace std;

// ... (Código das classes e templates)

class Estudante {
private:
  int matricula;
  string nome;
  int idade;
  double mediaNotas;

public:
  Estudante() {}

  Estudante(string nome, int matricula, int idade, double mediaNotas) {
    this->nome = nome;
    this->matricula = matricula;
    this->idade = idade;
    this->mediaNotas = mediaNotas;
  }

  string getNome() { return nome; }

  void setNome(string nome) { this->nome = nome; }

  int getMatricula() { return matricula; }

  void setMatricula(int matricula) { this->matricula = matricula; }

  int getIdade() { return idade; }

  void setIdade(int idade) { this->idade = idade; }

  double getMediaNotas() { return mediaNotas; }

  void setMediaNotas(double mediaNotas) { this->mediaNotas = mediaNotas; }

  bool operator<(const Estudante other) const { return this->nome < other.nome; }

  double operator/(const double value) const { return this->mediaNotas / value; }

  Estudante &operator+=(const Estudante &other) {
    this->mediaNotas += other.mediaNotas;
    return *this;
  }
};

class Disciplina {
private:
  int codigo;
  string nome;
  int horas;
  vector<string> estudantes;

public:
  Disciplina(int codigo, string nome, int horas) {
    this->codigo = codigo;
    this->nome = nome;
    this->horas = horas;
  }

  string getNome() { return nome; }

  void setNome(string nome) { this->nome = nome; }

  int getCodigo() { return codigo; }

  void setCodigo(int codigo) { this->codigo = codigo; }

  int getHoras() { return horas; }

  void setHoras(int horas) { this->horas = horas; }

  void adicionarEstudante(string estudante) { estudantes.push_back(estudante); }

  vector<string>::iterator comeco() { return estudantes.begin(); }

  vector<string>::iterator fim() { return estudantes.end(); }

  bool operator<(const Disciplina other) const {
    return this->nome < other.nome;
  }

  double operator/(const double value) const { return this->horas / value; }

  Disciplina &operator+=(const Disciplina &other) {
    this->horas += other.horas;
    return *this;
  }
};

template <typename T> class ConjuntoOrdenado {
private:
  set<T> dados;

public:
  void inserir(const T &valor) { dados.insert(valor); }

  T em(int indice) const {
    if (indice < 0 || indice >= contar()) {
      throw std::out_of_range("Índice fora do alcance");
    }
    auto it = dados.begin();
    advance(it, indice);
    return *it;
  }

  int contar() const { return dados.size(); }

  T soma() const {
    auto it = dados.begin();
    T resultado = *it;
    while (it != dados.end()) {
      it++;
      resultado += *it;
    }
    return resultado;
  }

  double media() const {
    if (dados.empty()) {
      return 0.0;
    }
    return soma() / contar();
  }
};

template <typename T> class ConjuntoDesordenado {
private:
  vector<T> dados = vector<T>();

public:
  void inserir(const T &valor) { dados.push_back(valor); }

  T em(int indice) const {
    if (indice < 0 || indice >= contar()) {
      throw std::out_of_range("Índice fora do alcance");
    }
    return dados[indice];
  }

  int contar() const { return dados.size(); }

  T soma() const {
    auto it = dados.begin();
    T resultado = *it;
    while (it != dados.end()) {
      it++;
      resultado += *it;
    }
    return resultado;
  }

  double media() const {
    if (dados.empty()) {
      return 0.0;
    }
    return soma() / contar();
  }
};

int main() {
  ConjuntoOrdenado<Estudante> estudantesOrdenados;

  // Adicionar alguns estudantes ao conjunto
  estudantesOrdenados.inserir(Estudante("Ana", 2214001, 22, 9.0));
  estudantesOrdenados.inserir(Estudante("Carlos", 2214002, 20, 8.5));
  estudantesOrdenados.inserir(Estudante("Mariana", 2214003, 21, 8.2));

  // Testar se o conjunto está ordenado corretamente
  assert(estudantesOrdenados.em(0).getNome() == "Ana");
  assert(estudantesOrdenados.em(1).getNome() == "Carlos");
  assert(estudantesOrdenados.em(2).getNome() == "Mariana");

  // Testar se o método contar está funcionando corretamente
  assert(estudantesOrdenados.contar() == 3);

  // Testar se a soma das médias de notas está correta
  assert(estudantesOrdenados.soma().getMediaNotas() == 25.7);

  // Testar se a média das médias de notas está correta
  assert(estudantesOrdenados.media() == 8.566666666666666);

  // Testar o ConjuntoDesordenado
  ConjuntoDesordenado<Estudante> estudantesDesordenados;

  // Adicionar alguns estudantes ao conjunto
  estudantesDesordenados.inserir(Estudante("Ana", 2214001, 22, 9.0));
  estudantesDesordenados.inserir(Estudante("Carlos", 2214002, 20, 8.5));
  estudantesDesordenados.inserir(Estudante("Mariana", 2214003, 21, 8.2));

  // Testar se o conjunto está ordenado corretamente
  assert(estudantesDesordenados.em(0).getNome() == "Ana");
  assert(estudantesDesordenados.em(1).getNome() == "Carlos");
  assert(estudantesDesordenados.em(2).getNome() == "Mariana");

  // Testar se a soma das médias de notas está correta
  assert(estudantesDesordenados.soma().getMediaNotas() == 25.7);

  // Testar se a média das médias de notas está correta
  assert(estudantesDesordenados.media() == 8.566666666666666
