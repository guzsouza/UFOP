#include "../src/models/MySim.h"
#include <cmath>
#include <cassert>


//classes testes de aceitação
class ExponentialFlow : public Flow {
public:
  ExponentialFlow(int id, std::string title) : Flow(id, title) {}
  virtual double execute() const { 
    return getSource()->getAccumulator() * 0.01; 
  }
  virtual ~ExponentialFlow() {}
};

class LogisticalFlow : public Flow {
public:
  LogisticalFlow(int id, std::string title) : Flow(id, title) {}
  virtual double execute() const {
    double value = getTarget()->getAccumulator();
    return 0.01 * value * (1 - value / 70);
  }
  virtual ~LogisticalFlow() {}
};


//testes de aceitação

void exponentialFunctionalTest() {
  Model model(1, "model_1");
  System s1(1, "pop1", 100.0);
  System s2(2, "pop2", 0.0);
  ExponentialFlow f1(1, "Exponencial");

  model.add(&s1);
  model.add(&s2);
  model.add(&f1);

  f1.setSource(&s1);
  f1.setTarget(&s2);

  model.execute(0, 100, 1);

  assert(fabs((round((s1.getAccumulator() * 10000)) - 10000 * 36.6032)) < 0.0001);
  assert(fabs((round((s2.getAccumulator() * 10000)) - 10000 * 63.3968)) < 0.0001);
}

void logisticalFunctionalTest() {
  Model model(1, "model_1");
  System s1(1, "pop1", 100.0);
  System s2(2, "pop2", 10.0);
  LogisticalFlow f1(1, "Logístico");

  model.add(&s1);
  model.add(&s2);
  model.add(&f1);

  f1.setSource(&s1);
  f1.setTarget(&s2);

  model.execute(0, 100, 1);

  assert(fabs((round((s1.getAccumulator() * 10000)) - 10000 * 88.2167)) < 0.0001);
  assert(fabs((round((s2.getAccumulator() * 10000)) - 10000 * 21.7833)) < 0.0001);
}

void complexFunctionalTest() {
  Model model(1, "acceptance_3");
  System q1(1, "q1", 100.0);
  System q2(2, "q2", 0.0);
  System q3(3, "q3", 100.0);
  System q4(4, "q4", 0.0);
  System q5(5, "q5", 0.0);

  ExponentialFlow f(1, "f");
  ExponentialFlow t(2, "t");
  ExponentialFlow u(3, "u");
  ExponentialFlow v(4, "v");
  ExponentialFlow g(5, "g");
  ExponentialFlow r(6, "r");

  model.add(&q1);
  model.add(&q2);
  model.add(&q3);
  model.add(&q4);
  model.add(&q5);

  model.add(&f);
  model.add(&t);
  model.add(&u);
  model.add(&v);
  model.add(&g);
  model.add(&r);

  f.setSource(&q1);
  f.setTarget(&q2);

  t.setSource(&q2);
  t.setTarget(&q3);

  u.setSource(&q3);
  u.setTarget(&q4);

  v.setSource(&q4);
  v.setTarget(&q1);

  g.setSource(&q1);
  g.setTarget(&q3);

  r.setSource(&q2);
  r.setTarget(&q5);

  model.execute(0, 100, 1);

  assert(fabs((round((q1.getAccumulator() * 10000)) - 10000 * 31.8513)) < 0.0001);
  assert(fabs((round((q2.getAccumulator() * 10000)) - 10000 * 18.4003)) < 0.0001);
  assert(fabs((round((q3.getAccumulator() * 10000)) - 10000 * 77.1143)) < 0.0001);
  assert(fabs((round((q4.getAccumulator() * 10000)) - 10000 * 56.1728)) < 0.0001);
  assert(fabs((round((q5.getAccumulator() * 10000)) - 10000 * 16.4612)) < 0.0001);
}

int main(){
  exponentialFunctionalTest();
  logisticalFunctionalTest();
  complexFunctionalTest();
  return 0;
}