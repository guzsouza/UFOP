g++ -Wall src/models/MySim.cpp -c
g++ -Wall tests/main.cpp -c
g++ main.o MySim.o -lm -o exe
rm *.o
./exe