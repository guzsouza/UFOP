#include "MySim.h"

//System

System :: System(){};
System :: System(int argument_id, std::string argument_title, double argument_accumulator):
    id(argument_id), 
    title(argument_title),
    accumulator(argument_accumulator)
{};
System :: ~System(){};
const double System :: getAccumulator(){
    return accumulator;
};
void System :: setAccumulator(double argument_accumulator){
    accumulator = argument_accumulator;
};
System :: System(const System &copyOther){
    if(this != &copyOther){
        accumulator = copyOther.accumulator;
    }
};
System& System :: operator=(const System &newOther){
    if (this != &newOther){
        accumulator = newOther.accumulator;
    }
    return *this;
};

//Flow

Flow :: Flow(){};
Flow :: Flow(int argument_id, std::string argument_title, System *argument_source, System *argument_target):
    id(argument_id),
    title(argument_title),
    source(argument_source),
    target(argument_target)
{};
Flow :: Flow(const Flow &copyOther){
    if(this != &copyOther){
        source = copyOther.source;
        target = copyOther.target;
    }
}
Flow::Flow(int argument_id, std::string argument_title)
      : id(argument_id), title(argument_title){}

Flow :: ~Flow(){};
Flow & Flow :: operator=(const Flow &newOther){
    if(this != &newOther){
        source = newOther.source;
        target = newOther.target;
    }
    return *this;
}
void Flow :: setTarget(System *newTarget){
    target = newTarget;
};
void Flow :: setSource(System *newSource){
    source = newSource;
};
void Flow :: clearSource(){
    source = nullptr;
};
void Flow :: clearTarget(){
    target = nullptr;
};

System *Flow :: getTarget() const{
    return target;
}

System *Flow :: getSource() const{
    return source;
}

//Model

Model::Model() {}

Model::Model(int argument_id, std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows)
    : id(argument_id), title(argument_title),  systems(systems), flows(flows){};

Model::Model(int argument_id, std::string argument_title)
    : id(argument_id), title(argument_title),  systems({}), flows({}){};

Model::Model(const Model &copyOther) {
  if (this != &copyOther) {
    id = copyOther.id;
    title = copyOther.title;
    flows = copyOther.flows;
    systems = copyOther.systems;
  }
}

std::vector<System *> Model::getSystems() const { 
    return systems; 
}

std::vector<Flow *> Model :: getFlows() const { 
    return flows; 
}

Model &Model ::operator=(const Model &newOther) {
  if (this != &newOther) {
    id = newOther.id;
    title = newOther.title;
    systems = newOther.systems;
    flows = newOther.flows;
  }
  return *this;
}

Model::~Model(){};

bool Model::add(Flow *newFlow) {
  flows.push_back(newFlow);
  return true;
}

bool Model::add(System *newSystem) {
  systems.push_back(newSystem);
  return true;
}

bool Model::execute(int initial_time, int end_time, int step) {
  for (int i = initial_time; i < end_time; i += step) {
      double flows_results[flows.size()];

      for (auto it = flows.begin(); it != flows.end(); ++it) {
        double result = (*it)->execute();
        flows_results[it - flows.begin()] = result;
      }

      for (size_t j = 0; j < flows.size(); j++) {
        System *source = flows[j]->getSource();
        source->setAccumulator(source->getAccumulator() - flows_results[j]);

        System *target = flows[j]->getTarget();
        target->setAccumulator(target->getAccumulator() + flows_results[j]);
      }
    }

    return true;
}
