#include <string>
#include <vector>
#include <typeinfo>

//System

class System{
    private:
        int id;
        std::string title;
        double accumulator;
    public:
        System();
        System(int argument_id, std::string argument_title, double argument_accumulator);
        System(const System &copyOther);
        virtual ~System();
        const double getAccumulator();
        void setAccumulator(double argument_accumulator);
        System &operator=(const System &newOther);       
};

//Flow

class Flow{
    private:
        int id;
        std::string title;
        System *source;
        System *target;
    public:
        Flow();
        Flow(int argumente_id, std::string argument_title, System *argument_source, System *argument_target);
        Flow(int argument_id, std::string argument_title);
        Flow(const Flow &copyOther);
        Flow &operator=(const Flow &newOther);
        virtual ~Flow();
        void setTarget(System *newTarget);
        void setSource(System *newSource);
        System *getSource() const;
        System *getTarget() const;
        void clearSource();
        void clearTarget();
        virtual double execute() const = 0;
};


//Model


class Model{
    private:
        int id;
        std::string title;
        std::vector<System*> systems;
        std::vector<Flow*> flows;
    public:
        Model();
        Model(int argument_id, std::string argument_title, std::vector<System*> systems, std::vector<Flow*> flows);
        Model(int argument_id, std::string argument_title);
        Model(const Model &copyOther);
        std::vector<System *> getSystems() const;
        std::vector<Flow *> getFlows() const;
        Model &operator=(const Model &newOther);
        bool add(Flow *newFlow);
        bool add(System *newSystem);
        bool execute(int initialTime, int endTime, int step);
        virtual ~Model();
};