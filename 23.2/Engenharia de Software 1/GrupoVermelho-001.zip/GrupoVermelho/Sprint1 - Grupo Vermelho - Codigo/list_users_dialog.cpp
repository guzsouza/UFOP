#include "list_users_dialog.h"
#include "ui_list_users_dialog.h"
#include "update_user_dialog.h"
#include <QtSql>
#include <QMessageBox>

ListUsersDialog::ListUsersDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ListUsersDialog)
{
    ui->setupUi(this);

    QSqlQuery query;
    query.prepare("select * from users");
    if(query.exec()) {
        int count = 0;
        ui->users_table->setColumnCount(4);
        while(query.next()) {
            ui->users_table->insertRow(count);
            ui->users_table->setItem(count, 0, new QTableWidgetItem(query.value(0).toString()));
            ui->users_table->setItem(count, 1, new QTableWidgetItem(query.value(2).toString()));
            ui->users_table->setItem(count, 2, new QTableWidgetItem(query.value(3).toString()));
            ui->users_table->setItem(count, 3, new QTableWidgetItem(query.value(4).toString()));
            ui->users_table->setRowHeight(count, 20);
            count++;
        }
        ui->users_table->setColumnWidth(0, 20);
        ui->users_table->setColumnWidth(1, 80);
        ui->users_table->setColumnWidth(2, 200);
        ui->users_table->setColumnWidth(3, 200);

        QStringList table_headers = {"ID", "Nome", "E-mail", "Senha"};
        ui->users_table->setHorizontalHeaderLabels(table_headers);
        ui->users_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        ui->users_table->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->users_table->verticalHeader()->setVisible(false);

    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao buscar usuário!");
    }
}

ListUsersDialog::~ListUsersDialog()
{
    delete ui;
}


void ListUsersDialog::on_delete_button_clicked()
{
    int line = ui->users_table->currentRow();
    int id = ui->users_table->item(line, 0)->text().toInt();

    QSqlQuery query;
    query.prepare("delete from users where users.id = :id");
    query.bindValue(":id", id);

    if(query.exec()) {
        QMessageBox::information(this, "SUCESSO", "Usuário removido com sucesso!");
    }else {
        QMessageBox::warning(this, "ERRO", "Falha ao remover usuário!");
    }

    ui->users_table->removeRow(line);
}


void ListUsersDialog::on_edit_button_clicked()
{
    int line = ui->users_table->currentRow();
    int id = ui->users_table->item(line, 0)->text().toInt();

    UpdateUserDialog update_user_dialog(this, id);
    update_user_dialog.exec();

    QSqlQuery query;
    query.prepare("select * from users where id = :id");
    query.bindValue(":id", id);

    if(query.exec()) {
        query.first();
        ui->users_table->setItem(line, 1, new QTableWidgetItem(query.value(2).toString()));
        ui->users_table->setItem(line, 2, new QTableWidgetItem(query.value(3).toString()));
        ui->users_table->setItem(line, 3, new QTableWidgetItem(query.value(4).toString()));
    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao atualizar tabela!");
    }
}

