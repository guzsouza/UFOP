#ifndef UPDATE_USER_DIALOG_H
#define UPDATE_USER_DIALOG_H

#include <QDialog>

namespace Ui {
class UpdateUserDialog;
}

class UpdateUserDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UpdateUserDialog(QWidget *parent = nullptr, int user_id = 0);
    ~UpdateUserDialog();

private slots:
    void on_save_button_clicked();

    void on_cancel_button_clicked();

private:
    Ui::UpdateUserDialog *ui;
};

#endif // UPDATE_USER_DIALOG_H
