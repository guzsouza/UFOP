#include "create_immobile_dialog.h"
#include "ui_create_immobile_dialog.h"
#include <QMessageBox>
#include <QtSql>

CreateImmobileDialog::CreateImmobileDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CreateImmobileDialog)
{
    ui->setupUi(this);
}

CreateImmobileDialog::~CreateImmobileDialog()
{
    delete ui;
}

void CreateImmobileDialog::on_save_button_clicked()
{
    QString street = ui->street_line_edit->text();
    QString city= ui->city_line_edit->text();
    QString state = ui->state_line_edit->text();
    QString zip = ui->zip_line_edit->text();
    QString price = ui->price_line_edit->text();
    QString rooms = ui->rooms_line_edit->text();
    QString area = ui->area_line_edit->text();
    QString parking_spaces = ui->parking_spaces_line_edit->text();
    QString owner_id = ui->user_id_line_edit->text();
    Qt::CheckState is_furnished = ui->is_furnished_check_box->checkState();
    Qt::CheckState is_pet_friendly = ui->is_pet_friendly_check_box->checkState();

    QSqlQuery query;
    query.prepare("insert into immobiles (street, city, state, zip, price_in_cents, rooms, area, parking_spaces, is_furnished, is_pet_friendly, owner_id)"
                  "values (:street, :city, :state, :zip, :price_in_cents, :rooms, :area, :parking_spaces, :is_furnished, :is_pet_friendly, :owner_id)");

    query.bindValue(":street", street);
    query.bindValue(":city", city);
    query.bindValue(":state", state);
    query.bindValue(":zip", zip);
    query.bindValue(":area", area);
    query.bindValue(":price_in_cents", price);
    query.bindValue(":area", area);
    query.bindValue(":owner_id", owner_id);
    query.bindValue(":is_furnished", is_furnished);
    query.bindValue(":is_pet_friendly", is_pet_friendly);
    query.bindValue(":rooms", rooms);
    query.bindValue(":parking_spaces", parking_spaces);

    if(query.exec()){
        QMessageBox::information(this, "", "Registro salvo com sucesso!");
        ui->street_line_edit->clear();
        ui->city_line_edit->clear();
        ui->state_line_edit->clear();
        ui->zip_line_edit->clear();
        ui->price_line_edit->clear();
        ui->rooms_line_edit->clear();
        ui->area_line_edit->clear();
        ui->parking_spaces_line_edit->clear();
        ui->user_id_line_edit->clear();
    } else {
        QMessageBox::information(this, "", query.lastError().text());
        qDebug() << "Falha ao salvar registro";
    }
}

