#ifndef CREATE_IMMOBILE_DIALOG_H
#define CREATE_IMMOBILE_DIALOG_H

#include <QDialog>

namespace Ui {
class CreateImmobileDialog;
}

class CreateImmobileDialog : public QDialog
{
    Q_OBJECT

public:
    explicit CreateImmobileDialog(QWidget *parent = nullptr);
    ~CreateImmobileDialog();

private slots:
    void on_save_button_clicked();

private:
    Ui::CreateImmobileDialog *ui;
};

#endif // CREATE_IMMOBILE_DIALOG_H
