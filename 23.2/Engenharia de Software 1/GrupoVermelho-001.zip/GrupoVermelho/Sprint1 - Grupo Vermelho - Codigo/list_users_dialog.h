#ifndef LISTUSERSDIALOG_H
#define LISTUSERSDIALOG_H

#include <QDialog>

namespace Ui {
class ListUsersDialog;
}

class ListUsersDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ListUsersDialog(QWidget *parent = nullptr);
    ~ListUsersDialog();

private slots:
    void on_delete_button_clicked();

    void on_edit_button_clicked();

private:
    Ui::ListUsersDialog *ui;
};

#endif // LISTUSERSDIALOG_H
