#include "create_user_dialog.h"
#include "ui_create_user_dialog.h"

#include <QtSql>
#include <QMessageBox>

CreateUserDialog::CreateUserDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::CreateUserDialog)
{
    ui->setupUi(this);
}

CreateUserDialog::~CreateUserDialog()
{
    delete ui;
}

void CreateUserDialog::on_save_button_clicked()
{
    QString name = ui->name_line_edit->text();
    QString email = ui->email_line_edit->text();
    QString password = ui->password_line_edit->text();

    QSqlQuery query;
    query.prepare("insert into users (name, email, password)"
                  " values (:name, :email, :password)");
    query.bindValue(":name", name);
    query.bindValue(":email", email);
    query.bindValue(":password", password);


    if(query.exec()){
        QMessageBox::information(this, "", "Registro salvo com sucesso!");
        ui->name_line_edit->clear();
        ui->email_line_edit->clear();
        ui->password_line_edit->clear();
        ui->name_line_edit->setFocus();
    } else {
        QMessageBox::information(this, "", query.lastError().text());
        qDebug() << "Falha ao salvar registro";
    }
}

