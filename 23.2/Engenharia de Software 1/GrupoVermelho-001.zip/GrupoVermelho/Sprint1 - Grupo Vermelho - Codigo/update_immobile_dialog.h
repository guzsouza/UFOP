#ifndef UPDATE_IMMOBILE_DIALOG_H
#define UPDATE_IMMOBILE_DIALOG_H

#include <QDialog>

namespace Ui {
class UpdateImmobileDialog;
}

class UpdateImmobileDialog : public QDialog
{
    Q_OBJECT

public:
    explicit UpdateImmobileDialog(QWidget *parent = nullptr, int immobile_id = 0);
    ~UpdateImmobileDialog();

private slots:
    void on_save_button_clicked();

    void on_cancel_button_clicked();

private:
    Ui::UpdateImmobileDialog *ui;
};

#endif // UPDATE_IMMOBILE_DIALOG_H
