#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "create_user_dialog.h"
#include "create_immobile_dialog.h"
#include "list_users_dialog.h"
#include "list_immobiles_dialog.h"
#include <QtSql>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("/run/user/1000/doc/9fffd189/test.db");

    if (!db.open()) {
        QMessageBox::warning(this, "ERRO", "Não foi possível estabelecer conexão com o banco de dados!");
    }

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_add_user_button_clicked()
{
    CreateUserDialog user_dialog;
    user_dialog.exec();
}


void MainWindow::on_add_immobile_button_clicked()
{
    CreateImmobileDialog immobile_dialog;
    immobile_dialog.exec();
}


void MainWindow::on_pushButton_2_clicked()
{
    ListUsersDialog list_users_dialog;
    list_users_dialog.exec();
}


void MainWindow::on_pushButton_4_clicked()
{
    ListImmobilesDialog list_immobiles_dialog;
    list_immobiles_dialog.exec();
}

