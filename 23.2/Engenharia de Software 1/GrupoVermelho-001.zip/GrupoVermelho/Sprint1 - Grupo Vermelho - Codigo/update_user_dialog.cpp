#include "update_user_dialog.h"
#include "ui_update_user_dialog.h"
#include <QtSql>
#include <QMessageBox>

UpdateUserDialog::UpdateUserDialog(QWidget *parent, int user_id)
    : QDialog(parent)
    , ui(new Ui::UpdateUserDialog)
{
    ui->setupUi(this);
    ui->id_label->setText(QString::number(user_id));
    QSqlQuery query;
    query.prepare("select * from users where id = :id");
    query.bindValue(":id", QString::number(user_id));

    if(query.exec()) {
        query.first();
        ui->name_line_edit->setText(query.value(2).toString());
        ui->email_line_edit->setText(query.value(3).toString());
        ui->password_line_edit->setText(query.value(4).toString());

    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao buscar o usuário!");
    }
}

UpdateUserDialog::~UpdateUserDialog()
{
    delete ui;
}

void UpdateUserDialog::on_save_button_clicked()
{
    QString id = ui->id_label->text();
    QString name = ui->name_line_edit->text();
    QString email = ui->email_line_edit->text();
    QString password = ui->password_line_edit->text();

    QSqlQuery query;
    query.prepare("update users set name = :name, email = :email, password = :password where id = :id");
    query.bindValue(":name", name);
    query.bindValue(":email", email);
    query.bindValue(":password", password);
    query.bindValue(":id", id);

    if(query.exec()) {
        this->close();
    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao atualizar usuário!");
    }
}


void UpdateUserDialog::on_cancel_button_clicked()
{
    this->close();
}

