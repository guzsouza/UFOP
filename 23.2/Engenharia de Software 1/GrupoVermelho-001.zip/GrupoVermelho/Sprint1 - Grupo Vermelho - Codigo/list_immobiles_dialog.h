#ifndef LISTIMMOBILESDIALOG_H
#define LISTIMMOBILESDIALOG_H

#include <QDialog>

namespace Ui {
class ListImmobilesDialog;
}

class ListImmobilesDialog : public QDialog
{
    Q_OBJECT

public:
    explicit ListImmobilesDialog(QWidget *parent = nullptr);
    ~ListImmobilesDialog();

private slots:
    void on_delete_button_clicked();

    void on_edit_button_clicked();

private:
    Ui::ListImmobilesDialog *ui;
};

#endif // LISTIMMOBILESDIALOG_H
