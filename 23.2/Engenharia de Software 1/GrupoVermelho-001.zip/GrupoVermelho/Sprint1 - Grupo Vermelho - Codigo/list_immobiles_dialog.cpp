#include "list_immobiles_dialog.h"
#include "ui_list_immobiles_dialog.h"
#include "update_immobile_dialog.h"
#include <QtSql>
#include <QMessageBox>

ListImmobilesDialog::ListImmobilesDialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::ListImmobilesDialog)
{
    ui->setupUi(this);

    QSqlQuery query;
    query.prepare("select * from immobiles");
    if(query.exec()) {
        int count = 0;
        ui->immobiles_table->setColumnCount(11);
        while(query.next()) {
            ui->immobiles_table->insertRow(count);
            ui->immobiles_table->setItem(count, 0, new QTableWidgetItem(query.value(0).toString()));
            ui->immobiles_table->setItem(count, 1, new QTableWidgetItem(query.value(2).toString()));
            ui->immobiles_table->setItem(count, 2, new QTableWidgetItem(query.value(3).toString()));
            ui->immobiles_table->setItem(count, 3, new QTableWidgetItem(query.value(4).toString()));
            ui->immobiles_table->setItem(count, 4, new QTableWidgetItem(query.value(5).toString()));
            ui->immobiles_table->setItem(count, 5, new QTableWidgetItem(query.value(6).toString()));
            ui->immobiles_table->setItem(count, 6, new QTableWidgetItem(query.value(7).toString()));
            ui->immobiles_table->setItem(count, 7, new QTableWidgetItem(query.value(8).toString()));
            ui->immobiles_table->setItem(count, 8, new QTableWidgetItem(query.value(9).toString()));
            ui->immobiles_table->setItem(count, 9, new QTableWidgetItem(query.value(10).toString()));
            ui->immobiles_table->setItem(count, 10, new QTableWidgetItem(query.value(11).toString()));
            ui->immobiles_table->setRowHeight(count, 20);
            count++;
        }
        ui->immobiles_table->setColumnWidth(0, 20);
        ui->immobiles_table->setColumnWidth(1, 80);
        ui->immobiles_table->setColumnWidth(2, 200);
        ui->immobiles_table->setColumnWidth(3, 200);

        QStringList table_headers = {"ID", "Preço", "Quartos", "Metros quadrados", "Amigável aos animais", "Mobiliada", "Rua", "Cidade", "Estado", "CEP", "ID do dono"};
        ui->immobiles_table->setHorizontalHeaderLabels(table_headers);
        ui->immobiles_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
        ui->immobiles_table->setSelectionBehavior(QAbstractItemView::SelectRows);
        ui->immobiles_table->verticalHeader()->setVisible(false);

    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao buscar imóveis!");
    }
}

ListImmobilesDialog::~ListImmobilesDialog()
{
    delete ui;
}

void ListImmobilesDialog::on_delete_button_clicked()
{
    int line = ui->immobiles_table->currentRow();
    int id = ui->immobiles_table->item(line, 0)->text().toInt();

    QSqlQuery query;
    query.prepare("delete from immobiles where users.id = :id");
    query.bindValue(":id", id);

    if(query.exec()) {
        QMessageBox::information(this, "SUCESSO", "Imóvel removido com sucesso!");
    }else {
        QMessageBox::warning(this, "ERRO", "Falha ao remover imóvel!");
    }

    ui->immobiles_table->removeRow(line);
}


void ListImmobilesDialog::on_edit_button_clicked()
{
    int line = ui->immobiles_table->currentRow();
    int id = ui->immobiles_table->item(line, 0)->text().toInt();

    UpdateImmobileDialog update_immobile_dialog(this, id);
    update_immobile_dialog.exec();

    QSqlQuery query;
    query.prepare("select * from immobiles where id = :id");
    query.bindValue(":id", id);

    if(query.exec()) {
        query.first();
        ui->immobiles_table->setItem(line, 1, new QTableWidgetItem(query.value(2).toString()));
        ui->immobiles_table->setItem(line, 2, new QTableWidgetItem(query.value(3).toString()));
        ui->immobiles_table->setItem(line, 3, new QTableWidgetItem(query.value(4).toString()));
        ui->immobiles_table->setItem(line, 4, new QTableWidgetItem(query.value(5).toString()));
        ui->immobiles_table->setItem(line, 5, new QTableWidgetItem(query.value(6).toString()));
        ui->immobiles_table->setItem(line, 6, new QTableWidgetItem(query.value(7).toString()));
        ui->immobiles_table->setItem(line, 7, new QTableWidgetItem(query.value(8).toString()));
        ui->immobiles_table->setItem(line, 8, new QTableWidgetItem(query.value(9).toString()));
        ui->immobiles_table->setItem(line, 9, new QTableWidgetItem(query.value(10).toString()));
        ui->immobiles_table->setItem(line, 10, new QTableWidgetItem(query.value(11).toString()));
        ui->immobiles_table->setItem(line, 11, new QTableWidgetItem(query.value(12).toString()));
    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao atualizar tabela!");
    }
}

