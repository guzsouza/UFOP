#include "update_immobile_dialog.h"
#include "ui_update_immobile_dialog.h"
#include <QtSql>
#include <QMessageBox>

UpdateImmobileDialog::UpdateImmobileDialog(QWidget *parent, int immobile_id)
    : QDialog(parent)
    , ui(new Ui::UpdateImmobileDialog)
{
    ui->setupUi(this);
    ui->id_label->setText(QString::number(immobile_id));
    QSqlQuery query;
    query.prepare("select * from immobiles where id = :id");
    query.bindValue(":id", QString::number(immobile_id));

    if(query.exec()) {
        query.first();
        ui->price_line_edit->setText(query.value(2).toString());
        ui->rooms_line_edit->setText(query.value(3).toString());
        ui->area_line_edit->setText(query.value(4).toString());
        ui->parking_spaces_line_edit->setText(query.value(5).toString());
        ui->is_furnished_check_box->setChecked(query.value(6).toBool());
        ui->is_pet_friendly_check_box->setChecked(query.value(7).toBool());
        ui->street_line_edit->setText(query.value(8).toString());
        ui->city_line_edit->setText(query.value(9).toString());
        ui->state_line_edit->setText(query.value(10).toString());
        ui->zip_line_edit->setText(query.value(11).toString());
        ui->owner_id_line_edit->setText(query.value(12).toString());

    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao buscar o usuário!");
    }

}

UpdateImmobileDialog::~UpdateImmobileDialog()
{
    delete ui;
}

void UpdateImmobileDialog::on_save_button_clicked()
{
    QString id = ui->id_label->text();
    int price = ui->price_line_edit->text().toInt();
    int rooms = ui->rooms_line_edit->text().toInt();
    int area = ui->area_line_edit->text().toFloat();
    int parking_spaces = ui->parking_spaces_line_edit->text().toInt();
    bool is_furnished = ui->is_furnished_check_box->isChecked();
    bool is_pet_friendly = ui->is_pet_friendly_check_box->isChecked();
    QString street = ui->street_line_edit->text();
    QString city = ui->city_line_edit->text();
    QString state = ui->state_line_edit->text();
    QString zip = ui->zip_line_edit->text();
    QString owner_id = ui->owner_id_line_edit->text();

    QSqlQuery query;
    query.prepare("update immobiles set price_in_cents = :price, rooms = :rooms, area = :area, parking_spaces = :parking_spaces, "
                  "is_furnished = :is_furnished, is_pet_friendly = :is_pet_friendly, street = :street, city = :city, state = :state, zip = :zip, owner_id = :owner_id "
                  "where id = :id");

    query.bindValue(":price", price);
    query.bindValue(":rooms", rooms);
    query.bindValue(":area", area);
    query.bindValue(":parking_spaces", parking_spaces);
    query.bindValue(":is_furnished", is_furnished);
    query.bindValue(":is_pet_friendly", is_pet_friendly);
    query.bindValue(":street", street);
    query.bindValue(":city", city);
    query.bindValue(":state", state);
    query.bindValue(":zip", zip);
    query.bindValue(":owner_id", owner_id);
    query.bindValue(":id", id);

    if(query.exec()) {
        this->close();
    } else {
        QMessageBox::warning(this, "ERRO", "Falha ao atualizar imóvel!" + query.lastError().text());
    }
}


void UpdateImmobileDialog::on_cancel_button_clicked()
{
    this->close();
}

