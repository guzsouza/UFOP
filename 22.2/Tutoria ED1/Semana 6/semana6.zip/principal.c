#include "busca.h"

int main(){

    int * v = malloc(sizeof(int) * 1000);
    int chave;
    int posicao;

    for(int i = 0; i < 1000; i++){
        scanf("%d", &v[i]);
    }

    mergeSort(v, 0, 999);

    scanf("%d", &chave);

    free(v);

    posicao = buscaBinaria(v, 0, 999, chave);

    printf("chave %d na posicao %d\n", chave, posicao);

    return 0;
}