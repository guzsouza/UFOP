#include <stdio.h>
#include <stdlib.h>

void merge(int *v, int l, int m, int r);
void mergeSort(int *v, int l, int r);
int buscaBinaria(int *v, int esq, int dir, int buscado);