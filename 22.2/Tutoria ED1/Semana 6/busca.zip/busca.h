#include <stdio.h>
#include <stdlib.h>

int binarySearch(int *, int, int , int );
void merge(int *, int , int , int );
void mergeSort(int *, int , int );