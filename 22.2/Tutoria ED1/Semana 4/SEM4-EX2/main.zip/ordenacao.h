#ifndef ORDENACAO_H
#define ORDENACAO_H

int ordenacao(char *vetor, int size);

#endif