#include <stdio.h>
#include "lista.h"

int main(){

    if (Read_Arq()==0)
        printf("Alocação Mal sucedida!!");
    
    return 0;
}