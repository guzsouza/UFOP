Arquivo zip gerado em: 30/01/2023 22:25:07 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Semana 1 - Exercício 1