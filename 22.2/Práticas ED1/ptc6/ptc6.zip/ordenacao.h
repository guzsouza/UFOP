# ifndef ordenacao_h
# define ordenacao_h

void ordenacao(int *vetor, int n, int *movimentos);
//Manter como especificado
int *alocaVetor(int *vetor, int n);
//Manter como especificado
int *desalocaVetor(int *vetor);
# endif
