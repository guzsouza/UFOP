#ifndef OP_H
#define OP_H


float sum(float parcela1, float parcela2);
float sub(float minuendo, float subtraeno);
float mult(float fator1, float fator2);
float divi(float dividendo, float divisor);
float fact(float fator);
float expo(float base, float expoente);
float fibonacci(int elemento);
float raiz(float valor);

#endif