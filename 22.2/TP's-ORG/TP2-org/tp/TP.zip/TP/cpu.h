#ifndef CPU_H
#define CPU_H

#include "instruction.h"
#include "memory.h"

typedef struct {
    Instruction* instructions;
    RAM ram;
    Cache l1; // cache L1
    Cache l2; // cache L2
    Cache l3; // cache L3
    int hitL1, hitL2, hitL3, hitRAM;
    int missL1, missL2, missL3;
    int totalCost;
    // int tempoL1, tempoL2, tempoL3;
    // int usoL1, usoL2, usoL3;
} Machine;

void start(Machine*, Instruction*, int*);
void stop(Machine*);
void run(Machine*, int);
void printMemories(Machine*);

#endif // !CPU_H