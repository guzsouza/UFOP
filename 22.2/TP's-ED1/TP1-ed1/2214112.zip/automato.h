//Aluno: Ben Hur Samuel Santos Nogueira 
//Matrícula: 21.2.4149

//Kayo Xavier Nascimento Cavalcante Leite
//Matrícula: 21.2.4095

//Aluno: Gustavo Zacarias Souza
//Matrícula: 22.1.4112

#ifndef AUTOMATO_H
#define AUTOMATO_H

typedef struct{
    int **matriz;
    int size;
} TAD;

int **alocaReticulado(int size);
void desalocaReticulado(int ***matriz, int size);
void leituraReticulado(int **matriz, int size);
void evoluiReticulado(int **matriz, int size);
void imprimeReticulado(int **matriz, int size);

#endif
