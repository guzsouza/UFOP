//Aluno: Ben Hur Samuel Santos NOgueira 
//Matrícula: 21.2.4149

//Kayo Xavier Nascimento Cavalcante Leite
//Matrícula: 21.2.4095

//Aluno: Gustavo Zacarias Souza
//Matrícula: 22.1.4112

#include <stdio.h>
#include <stdlib.h>
#include "automato.h"

int **alocaReticulado(int size){
    int **matriz = (int **) malloc (size * sizeof(int *));
    for (int i = 0; i < size; i++)
        matriz[i] = (int *) malloc (size * sizeof(int));

    return matriz;
}

void desalocaReticulado(int ***matriz, int size){
    for (int i = 0; i < size; i++)
        free((*matriz)[i]);
    free(*matriz);
}

void leituraReticulado(int **matriz, int size){
    for (int i = 0; i < size; i++){
        for (int j = 0; j < size; j++){
            if (i == 0 || j == 0 || i == size-1 || j == size-1)
              matriz[i][j] = 9;
            else
              scanf (" %d", &matriz[i][j]);
        }
    }
}

void evoluiReticulado(int **matriz, int size){
    //Compara celulas
    for(int i=1; i < size-1; i++){
        for(int j=1; j < size-1; j++){
            int live = 0;
            if (matriz[i-1][j-1] == 1 || matriz[i-1][j-1] == -1) //left-up
                live++;
            if (matriz[i-1][j] == 1 || matriz[i-1][j] == -1) //up
                live++;
            if (matriz[i-1][j+1] == 1 || matriz[i-1][j+1] == -1) //right-up
                live++;
            if (matriz[i][j-1] == 1 || matriz[i][j-1] == -1) //left
                live++;
            if (matriz[i][j+1] == 1 || matriz[i][j+1] == -1) //right
                live++;
            if (matriz[i+1][j-1] == 1 || matriz[i+1][j-1] == -1) //left-down
                live++;
            if (matriz[i+1][j] == 1 || matriz[i+1][j] == -1) //down
                live++;
            if (matriz[i+1][j+1] == 1 || matriz[i+1][j+1] == -1) //right-down
                live++;

            if (matriz[i][j] == 1){
              if (live == 2 || live == 3) //Mantém viva
                  continue;
            
              if (live > 3){ //Sufocamento
                  matriz[i][j] = -1;
              }
              
              if (live < 2){//Subpopulação
                  matriz[i][j] = -1;
              }
            }
            else {
              if (live == 3)//Reprodução
                  matriz[i][j] = 2;
            }
        }
    }
}

void imprimeReticulado(int **matriz, int size){
    for(int i=1; i < size-1; i++){
        for(int j=1; j < size-1; j++){
            if (j != size-2){
                if (matriz[i][j] == 1 || matriz[i][j]== 2)
                    printf("1 ");
                if (matriz[i][j] == 0 || matriz[i][j]== -1)
                    printf("0 ");
            }
            else {
                if (matriz[i][j] == 1 || matriz[i][j]== 2)
                    printf("1");
                if (matriz[i][j] == 0 || matriz[i][j]== -1)
                    printf("0");
            }
        }
        printf ("\n");
    }
}
