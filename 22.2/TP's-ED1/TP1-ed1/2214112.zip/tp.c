//Aluno: Ben Hur Samuel Santos Nogueira
//Matrícula: 21.2.4149

//Kayo Xavier Nascimento Cavalcante Leite
//Matrícula: 21.2.4095

//Aluno: Gustavo Zacarias Souza
//Matrícula: 22.1.4112

#include <stdio.h>
#include "automato.h"

int main(){
    TAD reticulado;

    scanf (" %d", &reticulado.size);
    reticulado.size += 2;
    reticulado.matriz = alocaReticulado(reticulado.size);
  
    leituraReticulado(reticulado.matriz, reticulado.size);
  
    evoluiReticulado(reticulado.matriz, reticulado.size);
    
    imprimeReticulado(reticulado.matriz, reticulado.size);

    desalocaReticulado(&reticulado.matriz, reticulado.size);
    
    return 0;
}
