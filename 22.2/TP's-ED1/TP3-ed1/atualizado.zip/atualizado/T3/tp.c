#include <stdio.h>

#include "indiceInvertido.h"

int main() {
    int quantDocs;
    char nomeDoc[D], comando;
    Chave chaves[NN], listaPesquisa[NN];
    NomeDocumento resultadoPesquisa[ND];
    

    IndiceInvertido tabelaHash;
    inicia(tabelaHash);

    scanf("%d", &quantDocs);

    for(int i = 0; i < quantDocs; i++) {
        scanf("%s", nomeDoc);

        int quantChaves = pegarChaves(chaves);

        // passar o nomeDoc a hash table
        // for(int j = 0; j < quantChaves; j++) // passa as chaves[j] para a hash table
        for(int j = 0; j < quantChaves; j++) {
            if(!insereDocumento(tabelaHash, chaves[j], nomeDoc)) printf("ERROR: Problema pra adicionar chave\n");
        }
    }
    
    scanf("%c", &comando);

    if(comando == 'B') {
        int quantPesquisa = pegarChaves(listaPesquisa);
        int tamPesquisa = consulta(tabelaHash, listaPesquisa, quantPesquisa, resultadoPesquisa);
        if(tamPesquisa == -1)
            printf("none\n");
        else for(int i = 0; i < tamPesquisa; i++) printf("%s\n", resultadoPesquisa[i]);
    } 
    else if (comando == 'I') imprime(tabelaHash);

    return 0;
}
