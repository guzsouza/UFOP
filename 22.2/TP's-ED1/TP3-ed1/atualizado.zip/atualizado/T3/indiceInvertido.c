#include <stdio.h>
#include <string.h>

#include "indiceInvertido.h"


void merge(char **arr, int left, int mid, int right) {
    int i, j, k;
    int n1 = mid - left + 1;
    int n2 = right - mid;
 
    char *L[n1], *R[n2];
 
    for (i = 0; i < n1; i++)
        L[i] = arr[left + i];
    for (j = 0; j < n2; j++)
        R[j] = arr[mid + 1 + j];
 
    i = 0;
    j = 0;
    k = left;

    while (i < n1 && j < n2) {
        if (strcmp(L[i], R[j]) <= 0) {
            arr[k] = L[i];
            i++;
        } else {
            arr[k] = R[j];
            j++;
        }
        k++;
    }
 
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }
 
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }
}
 
void mergeSort(char **arr, int left, int right) {
    if (left < right) {
        int mid = left + (right - left) / 2;
 
        mergeSort(arr, left, mid);
        mergeSort(arr, mid + 1, right);
 
        merge(arr, left, mid, right);
    }
}

void inicia(IndiceInvertido tabelaHash) {
    for(int i = 0; i < M; i++) {
        tabelaHash[i].n = 0;
        strcpy(tabelaHash[i].chave, VAZIO);

        for(int j = 0; j < ND; j++) strcpy(tabelaHash[i].documentos[j], VAZIO);
    }
}

bool insereDocumento(IndiceInvertido tabelaHash, Chave chave, NomeDocumento documento) {
    int posicao = busca(tabelaHash, chave);
    
    if(posicao == -1) {
        posicao = h(chave, M);
        strcpy(tabelaHash[posicao].chave, chave);
        strcpy(tabelaHash[posicao].documentos[tabelaHash[posicao].n], documento);
        tabelaHash[posicao].n++;
        tabelaHash[posicao].sofreuColisao = false;

        return 1;
    } else if(posicao >= 0 && posicao < M){

        strcpy(tabelaHash[posicao].documentos[tabelaHash[posicao].n], documento);
        tabelaHash[posicao].n++;

        return 1;
    }

    return 0;
}

int busca(IndiceInvertido tabelaHash, Chave chave) {
    int j = 0;
    int ini = h(chave, M);

    while(strcmp(tabelaHash[(ini + j) % M].chave, VAZIO) != 0 &&
          strcmp(tabelaHash[(ini + j) % M].chave, chave) != 0 &&
          j < M) {
            j++;
    }
    
    if(strcmp(tabelaHash[(ini + j) % M].chave, chave) == 0){
        return (ini + j) % M;
    }
    
    return -1;
}

int consulta(IndiceInvertido tabelaHash, Chave* listaPesquisa, int quantPesquisa, NomeDocumento* resultadoPesquisa) {
    // se chave não existir na tabela
    if (busca(tabelaHash, listaPesquisa[0]) < 0)
        return 0;

    x = busca(tabelaHash, listaPesquisa[0]);

    int tamIguais = tabelaHash[x].n;
    int listaIguais[tamIguais];
    NomeDocumento iguais[tamIguais] = tabelaHash[x].documentos;
    
    for(int i = 1; i < quantPesquisa; i++) {
        
        int cont = 0;
        int tamAux = tabelaHash[x].n;
        if (busca(tabelaHash, listaPesquisa[i]) < 0)
            return 0;
            
        y = busca(tabelaHash, listaPesquisa[i]);  

        NomeDocumento aux[tamAux] = tabelaHash[y].documentos;

        for(int j = 0; j < tamIguais; j++)
            for(int k = 0; k < tamAux; k++)
                if(iguais[])
    }

    


    //print dos documentos encontrados na pesquisa.
        //ordenação
    mergeSort(strings, 0, numStrings - 1);
        //print
    for (int i = 0; i < numStrings; i++) {
        printf("%s ", strings[i]);
    }

    return 1;
}

void imprime(IndiceInvertido tabela){
    
    for(int i=0; i<M; i++){
        // printf("%d\n", strcmp(tabela[i].chave, VAZIO));
        if (strcmp(tabela[i].chave, VAZIO) != 32 ){
            
            printf("%s - ", tabela[i].chave);
        
            for(int j=0; j<tabela[i].n; j++){
                printf("%s ", tabela[i].documentos[j]);
            }
            
            printf("\n");
        }
    }
}